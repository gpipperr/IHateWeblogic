---
nav_title: "Customer tools"
title: "Forms & Reports Customer Tools – Metadata and Patch Download"
description: "Standalone customer tools for Oracle Forms & Reports hosts, one ZIP per platform: metadata collection, setdb environment switcher, MOS patch download."
permalink: /70-Customer-Projects/tools/
---

# tools – metadata collection and patch download for a Forms & Reports host

Shared, standalone helpers for the patch analyses in `70-Customer-Projects/`
– **no** IHateWeblogic library, copy them to the host and run them there.

**For the customer: one ZIP per platform, one link** (no git clone on the
customer host):

| ZIP | Content | Link |
|---|---|---|
| [ihw_customer_tools_linux.zip](ihw_customer_tools_linux.zip) | `tools/*.sh` (all of `bash/` except the analysis, incl. [`ihw_tools_lib.sh`](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/tools/bash/ihw_tools_lib.sh)), `tools/doc/` (this README, the road map, `patch_install.ini.template`), `tools/VERSIONS.txt` | `https://github.com/gpipperr/IHateWeblogic/raw/main/70-Customer-Projects/tools/ihw_customer_tools_linux.zip` |
| [ihw_customer_tools_windows.zip](ihw_customer_tools_windows.zip) | `tools/*.ps1`, [`GetMOSPatchRunner.java`](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/tools/powershell/GetMOSPatchRunner.java), `tools/doc/README.md`, `tools/VERSIONS.txt` | `https://github.com/gpipperr/IHateWeblogic/raw/main/70-Customer-Projects/tools/ihw_customer_tools_windows.zip` |

Each with a `.sha256` next to it (same link + `.sha256`). Unpacked with
`unzip … -d $ORACLE_BASE` it gives `$ORACLE_BASE/tools/` – the layout of the
road map [Start_beim_Kunden_kochbuch_de.txt](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/Start_beim_Kunden_kochbuch_de.txt).

**Maintainer rule:** the ZIPs are built by
[make_customer_zip.sh](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/tools/make_customer_zip.sh) – deterministic (fixed time
stamps, sorted, no extra attributes), so they only change when a tool really
changed. Before **every commit** that touches a packed file – `bash/`,
`powershell/`, this README, the road map (`Start_beim_Kunden_kochbuch_de.txt`)
or the `patch_install.ini` template; the full list prints
`make_customer_zip.sh --sources`, and the pre-commit hook blocks a commit
that changes one of them without a current ZIP:

```bash
70-Customer-Projects/tools/make_customer_zip.sh            # check: exit 1 + changed files = stale
70-Customer-Projects/tools/make_customer_zip.sh --apply    # rebuild (+ .sha256), commit the ZIPs with the change
```

Not in the ZIPs: the local cookbook formatter.

| Folder | Platform |
|---|---|
| `bash/` | Linux – plain bash + coreutils (this README) |
| [powershell/](powershell/README.md) | MS Windows Server – Windows PowerShell 5.1 / PowerShell 7: [`collect_fmw_env.ps1`](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/tools/powershell/collect_fmw_env.ps1), [`export_forms_reports_conf.ps1`](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/tools/powershell/export_forms_reports_conf.ps1), [`fmw_patch_env.ps1`](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/tools/powershell/fmw_patch_env.ps1), [`java_check_fmw.ps1`](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/tools/powershell/java_check_fmw.ps1), [`mos_patch_download.ps1`](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/tools/powershell/mos_patch_download.ps1) (+ [`GetMOSPatchRunner.java`](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/tools/powershell/GetMOSPatchRunner.java)), same output / CSV format as the bash versions |

The bash scripts (`bash/`): one script for all releases – it works for FMW / Forms &
Reports **12.2.1.x** (12.2.1.19 on WLS 12.2.1.4, JDK 8) and **14.1.2** (JDK
17 / 21) – tested on both (2026-10-23). Release differences are detected at
runtime, never by a second copy of the script.

| Script | Purpose |
|---|---|
| [bash/collect_fmw_env.sh](#collect_fmw_envsh) | read-only collection of the **state**: installed products, patch level (Oracle, Java, OS advisories, Nginx), performance (memory, load profile), security / quality of operation (Derby, FADS, certificates) – input of the patch analysis and, with the export, of the environment analysis |
| [bash/collect_ords_apex.sh](#collect_ords_apexsh) | read-only collection of **ORDS / APEX** on the host (third collector): every ORDS installation (standalone / Tomcat / WebLogic / systemd / stopped), version, Java, pools + features (`ords config list`), APEX images version (`/i/`), web routes, security (listen address, SQL features, fixed auth headers, AJP, file users), logs of the last days aggregated – input of the ORDS / APEX analysis |
| [bash/java_check_fmw.sh](#java_check_fmwsh) | read-only: which Java does WebLogic / Node Manager / Reports / frmweb really use, is the FMW-bundled JDK (`oracle_common/jdk`) intact or bent, which files pin a missing or versioned JDK path – what to adjust after a JDK switch |
| [bash/check_fix_libzrc_glibc.sh](#check_fix_libzrc_glibcsh) | check (and with `--apply` repair) `lib/libzrc.so.0` / the link `libzrc.so` – the Forms relink after a Reports QPR on OL9 (MOS KB873815), leftovers of a failed Forms patch |
| [bash/mos_patch_download.sh](#mos_patch_downloadsh) | download a patch list (CSV) from My Oracle Support with getMOSPatch in one run |
| [bash/clone_check_fmw.sh](#clone_check_fmwsh) | read-only: is the installation clone-capable (golden image) – sockets, WebLogic, Reports ORB, host name / IP in the domain, RCU repository, web tier |
| [bash/fmw_patch_env.sh](#fmw_patch_envsh) | detect and set the variables of the manual patch cookbooks (`ORACLE_HOME`, `DOMAIN_HOME`, `INV_PTR`, `JDK_LINK`, `PATCH_DIR`, `STAGE`, `BACKUP` …) |
| [bash/export_forms_reports_conf.sh](#export_forms_reports_confsh) | read-only: export the customer-specific Forms & Reports **configuration** (formsweb.cfg, env files, cgicmd.dat, Reports servers, uifont.ali, custom fonts, customer jars, web tier, source paths + dependencies) into one encrypted archive – everything to build the environment again |
| [bash/ihw_shell_env.sh](#ihw_shell_envsh) | interactive: `setdb` / `setfmw` / `setfw` – one menu to switch the **current shell** between the FMW home, its domains and DB homes (with / without SID); `c` clear, `h` help, `wlst`, `cdlog` …, `domain`; puts `$ORACLE_BASE/tools` into the PATH (installed as `~/.bashrc.d/ihw_env.sh`) |
| [bash/update_tools_from_git.sh](#update_tools_from_gitsh) | update the tools of `$ORACLE_BASE/tools` from the repository: download the Linux ZIP (wget `--no-check-certificate`, curl `-k` fallback, or `--zip FILE` offline), show per file installed → repository version; `--apply` replaces / unpacks (backup first), installs `setdb` as `~/.bashrc.d/ihw_env.sh` and removes the template `ihw_shell_env.sh` from the tools directory |
| [bash/set_script_env.sh](#set_script_envsh-and-the-operation-tools) | sourced: load the customer's [`patch_install.ini`](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/Reports14_linux_manual_install/patch_install.ini) into the session for the cookbook commands; `set_script_env_show` lists the values |
| [bash/make_patch_install_ini.sh](#make_patch_install_inish) | create [`patch_install.ini`](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/Reports14_linux_manual_install/patch_install.ini) from the existing domain, for the cookbooks (dry run shows the values, `--apply` writes; offered by `setdb` at `t`) |
| [bash/status.sh, show_log.sh, show_errors.sh, show_all_logs.sh](#set_script_envsh-and-the-operation-tools) | operation (German output): status in three stages (ports, processes, HTTP + Node Manager, rc 0/1/2), the log of one component, all current logs live, only the error lines – read [`patch_install.ini`](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/Reports14_linux_manual_install/patch_install.ini) next to them |
| [bash/clean_domain_tmp.sh](#clean_domain_tmpsh) | delete the contents of `servers/*/tmp` and `cache` of a stopped domain, rebuilt at the next start, e.g. after a patch (dry run shows the sizes, `--apply` deletes, refuses while anything runs) |
| [bash/create_server_cert_from_pfx.sh](#create_server_cert_from_pfxsh) | split a customer PFX / PKCS#12 (e.g. wildcard certificate) into `server.key` / `server.cert` / `ca_chain.cert` for Apache / Nginx – without `--apply` only list the container (password, format, names / SAN, validity, key ↔ certificate, chain) |
| [bash/ihw_tools_lib.sh](#ihw_tools_libsh) | shared helpers of these tools (masking, ini parsing, font classes, git guard, Markdown tables) – sourced, lies next to the tools |
| [bash/check_disk_space.sh](#check_disk_spacesh) | read-only: where is the space of the local disks – usage tree, known space eaters with their clean command, deleted-but-open files, files > 500 MB; NFS / network mounts are never scanned |

Cookbooks (`*_Kochbuch_de.txt`): **a blank line after every command**
(customer request 2026-11-03).
All style rules: [../cookbook-Skill.md](../cookbook-Skill.md).

**Two tools, two analyses (2026-11-16)** – every analysis needs both runs on
the host:

| Tool | Collects | Analysis |
|---|---|---|
| `collect_fmw_env.sh` | what is installed where, patch level (Oracle, Java, OS security advisories, Nginx in detail), Java, memory, load profile, Derby, FADS, HTTPS certificates – masked, no configuration files | **patch analysis**: installed products, patch level, Java, OS, number of missing patches / advisories, Nginx, how to patch |
| `export_forms_reports_conf.sh` | the configuration (raw copies + `ihw_import/` proposals) for the rebuild | **environment analysis** (export + collection): configuration, security, performance, load profile, 14c target – the patch level only as one summary line |
| `collect_ords_apex.sh` | ORDS / APEX: installations, versions, pools, features, APEX images, web routes, security, aggregated logs – masked, the wallet never | **ORDS / APEX analysis** (third report): architecture, versions + upgrade (ORDS = new installation), pools / features, reachable from outside?, upgrade checklist |

Windows: [`powershell/collect_fmw_env.ps1`](powershell/README.md#collect_fmw_envps1) collects the same
state (with `powershell/ihw_tools_lib.ps1`; Nginx installed by hand in
detail, pending Windows updates), [`powershell/export_forms_reports_conf.ps1`](powershell/README.md#export_forms_reports_confps1)
exports the configuration with the same archive layout plus the Oracle
registry environment and a Windows → Linux path map. Both analyses read
Linux and Windows archives alike.

Order at a customer (tools → setdb → ini → analysis or installation):
[../Start_beim_Kunden_kochbuch_de.txt](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/Start_beim_Kunden_kochbuch_de.txt).

Used by:
- [Reports14_linux_manual_install](../Reports14_linux_manual_install/README.md)
  (all values in [patch_install.ini](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/Reports14_linux_manual_install/patch_install.ini))
- [FormsReports12_patch_cpu_2026-10](../FormsReports12_patch_cpu_2026-10/README.md)
  (patch list [patches_cpu_forms_reports_12c_oct2026.csv](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/FormsReports12_patch_cpu_2026-10/patches_cpu_forms_reports_12c_oct2026.csv))
- [FormsReports14_patch_cpu_2026-10](../FormsReports14_patch_cpu_2026-10/README.md)

## collect_fmw_env.sh

Collects the **state** of an Oracle Forms & Reports / FMW host – OS and its
open security advisories, Java, Oracle Home / inventory / patches, domain
facts, processes and memory, web tier (Nginx patch facts in detail), HTTPS
certificates, load profile, logs. The **configuration files** are not copied
(since 2026-11-16.3) – they are in the export
([`export_forms_reports_conf.sh`](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/tools/bash/export_forms_reports_conf.sh));
an analysis always needs both. Since 2026-11-05.1 the result is an
**encrypted ZIP** (`fmw_collect_<host>_<ts>.zip.enc` + `.sha256`) – masked,
but with host names, IPs and paths of the customer.

```bash
# as the software owner of the Oracle Home (oracle), not root - from the
# unpacked tools ZIP (needs ihw_tools_lib.sh next to it)
cd $ORACLE_BASE/tools
./collect_fmw_env.sh                    # auto-detect, passphrase asked twice at the start
./collect_fmw_env.sh --no-encrypt       # plain ZIP (still masked) - e.g. without a terminal
./collect_fmw_env.sh -o /oracle/product/mw -d /oracle/user_projects/domains/fr_domain
./collect_fmw_env.sh --full             # + opatch lsinventory -details / -bugs_fixed
./collect_fmw_env.sh --logs             # + error lines of the server logs (last 200)
```

| Option | Meaning |
|---|---|
| `-o DIR` | Oracle Home (default: `$ORACLE_HOME`, then `/oracle/product/mw`, `/u01/app/oracle/fmw`, …) |
| `-d DIR` | domain home (default: `$DOMAIN_HOME`, `$ORACLE_HOME/domain-registry.xml`, the running AdminServer) |
| `-t DIR` | base directory of the output (default `/tmp`) |
| `--full` | large inventory output – for bug / CVE questions (`-bugs_fixed`) |
| `--logs` | error / FRM- / REP- / ORA- lines of the server logs |
| `--no-encrypt` | plain `.zip` instead of `.zip.enc` (the content is masked in both cases) |
| `--keep` | keep the output directory next to the archive |
| `--no-load` | no load profile (default: on – `load/`, see [export_forms_reports_conf.sh](#export_forms_reports_confsh) for the files) |
| `--load-days N` | period of the load profile (access logs / sar files changed in the last N days, default 90) |
| `--rw-auth USER` | Reports admin (`<identifier>`) for `getserverinfo` / `showjobs` of a **secured** Reports server – password asked hidden at the start; non-interactive: `IHW_RW_AUTH=user/password` in the environment. Passed to curl only via a config on stdin (never on the command line) |

**Since 2026-11-16.3:**

| File / fact | Content |
|---|---|
| `20_java.txt` block `Java4Shell (CVE-2026-114938) …`, fact `Java4Shell CVE-2026-114938` (2026-11-18.1) | normalised `java4shell;key;…` lines (`ihwt_java4shell`): `cpu` (model, `avx512f` / `avx512bw` / `avx512vbmi` / `bmi2`, `vulnerable=yes` only with all four), `bundled_jdk` (version of `oracle_common/jdk`: `affected` / `not-affected` / `java8` / `none`), `reports_sh` (`-XX:-UseBASE64Intrinsics` in `REPORTS_JVM_OPTIONS`), `engine` (every engine with `jvmOptions` in a `rwserver.conf` of the domain), `process` (every process of the user on the bundled JDK – engines: command line, native `rwserver`: `REPORTS_JVM_OPTIONS` in its environment); Windows (`collect_fmw_env.ps1` 2026-11-18.1): same lines plus `source=` of the CPU features ([powershell/README.md](powershell/README.md#collect_fmw_envps1)) – background: [00-patch-references.md – Java4Shell](../../09-Install/docs/00-patch-references.md#java4shell--cve-2026-114938-state-2026-11-18) |
| `10_os.txt`, facts `OS security advisories`, `dnf cache age (days)` | open OS security advisories from the **dnf cache** (`dnf --cacheonly updateinfo list --security`, no network) – the analyses show only the numbers |
| `61_webserver.txt` block `Nginx patch facts`, facts `Nginx …` | Nginx version, OpenSSL (built / running), package and origin (OS repository / nginx.org / own build), module stream, update available, open nginx / openssl advisories, master start time against the package install time (`restart pending`), modules and `load_module` lines |
| facts `Apache WebLogic plug-in`, `Apache ProxyPass routes`, `httpd restart pending` | web tier patch facts derived from the configuration (the configuration itself: export) |
| `62_certificates.txt`, fact `HTTPS certificates` | subject / issuer / expiry of every HTTPS listener (moved from the export); since 2026-11-16.7 also **SAN** (DNS names / IPs), **key** (`RSA 2048`, `EC 256`), **signature algorithm** and **chain** (number of certificates the server sends, `file` when only the certificate file was readable) – columns appended, the first four unchanged |
| `10_os.txt` block `Listening ports (normalised …)`, fact `Listening ports` | every listening TCP port as `port;addr;port;scope;pid;process` – scope `local` (loopback), `ip` (one address) or `all` (every interface); process names without root only for the software owner (2026-11-16.7) |
| `40_domain.txt` block `Domain summary (top level)` | servers / listen addresses / ports / running and the **WebLogic plug-in** flag of the Forms domain (`ihwt_domain_summary`) |
| `load/` | the load profile (moved from the export) |
| facts `Forms in domain`, `TNS_ADMIN (environment)`, identification (`Platform`, `FMW version`, `CPUs`, `RAM MB`) | for the analyses; `40_domain.txt` / `60_net.txt` list the configuration files with date and size, without content |

**Since 2026-11-16.4 (`.ps1` 2026-11-16.5) – licence indicators, no licence statement**
([80-FMW-Architecture/fmw_forms_reports_licence.md](../../80-FMW-Architecture/fmw_forms_reports_licence.md)):

| File / fact | Content |
|---|---|
| `45_licence.txt` block `WebLogic Server Basic indicators` | offline from `config.xml`, `config/jdbc`, `config/jms`: the WebLogic Server Basic restrictions of MOS note 885587.1 that need no running server (cluster constraints, ADMIN / STANDBY start, automatic migration, overload actions, MAN / WAN replication, singleton services, global Work Managers, SAF agents, Tuxedo Connector, SNMP, own WLDF modules, standalone JDBC / JMS modules, HTTP Pub-Sub, Active GridLink, JMS Unit-of-Order / Unit-of-Work), every application and library with "source in ORACLE_HOME", production / secure mode and administration port |
| `45_licence.txt` block `Host (licence context)` | CPU sockets / cores / threads / model / architecture, virtualization, **public cloud** (`host;cloud` = `oci` / `aws` / `azure` / `gcp` / `none` from the DMI data as cloud-init reads it, e.g. chassis asset tag `OracleCloud.com`), Oracle Database instances with the **edition chosen at installation** (`oracle_install_db_InstallEdition` of the home, instance → home via `/proc/<pmon>/exe`; every DB home of the inventory), ORDS processes on the host, WebLogic domains of the home |
| `46_security.txt`, facts `Domain key / boot.properties`, `Lockout / password rule`, `Audit`, `Domain owner groups`, `ORDS version` (2026-11-19.1) | the checks of `02-Checks/domain_secret_check.sh` as normalised `security;key;…` lines (`ihwt_security`), rated by the analysis: mode / owner / group (+ further group members) of `SerializedSystemIni.dat`, `config.xml`, `config/jdbc/*.xml` and every `boot.properties` (incl. the Node Manager cache), clear-text `boot.properties`, account lockout and password rule of the realm (`config.xml`, prefix `sec:` / `pas:`), configuration audit + auditing provider, OPSS `audit.filterPreset` of the default jpsContext (`jps-config.xml`), applications on the AdminServer besides the FMW infrastructure, groups of the domain owner (admin / DB groups, database on the host), further copies of a domain key below `ORACLE_BASE`, `umask` of the login profile, **ORDS version** of every `ords.war` (process / domain deployment – compared with `ORDS_VERSION_MIN` of the cycle). Values are never stored; `sudo` is **not** probed (no sudo call on a customer host) |
| `72_forms_crashes.txt` + `dumps/`, facts `Forms env library paths`, `Forms crashes (logs)`, `Forms frmweb dumps` (2026-11-24.1) | `envpath;` lines: every `LD_PRELOAD` / `LD_LIBRARY_PATH` entry of the Forms env files – exists on the host? versioned JDK directory instead of the link? (a JDK removed after an update leaves `libjsig.so` unloadable); `crash_day;` lines: runtime crashes (`terminating due to signal N`), `cannot be preloaded` errors and written stack traces per day from `formsapp-diagnostic*.log`; `frmweb_dump;` lines: one summary per `frmweb_dump_<pid>` (form / block / field, last trigger, signal or internal error, top frames, call stack signature – `ihwt_frmweb_dump`), the newest 10 dumps copied to `dumps/` (max 1 MB each, masked). A dump is a TEXT stack trace frmweb writes itself – no core file, no gdb needed; single dumps: `customer-analyse/frmweb_dump_analyse.sh` |
| facts `WLS Basic indicators`, `Deployments (apps / libs)`, `WLS secure mode / admin port`, `CPU (sockets/cores/threads)`, `Virtualization`, `Public cloud / CPU arch`, `Oracle DB on this host`, `ORDS on this host` | the summary; the environment analysis compares the deployments with `rules/wls_basic_ofr_allowlist.txt` (section 13.5) and counts a cloud instance by the cloud rules (OCI: OCPUs, AWS / Azure / Google Cloud: vCPUs) |

Encryption: the same as the configuration export ([`ihw_tools_lib.sh`](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/tools/bash/ihw_tools_lib.sh)
`ihwt_read_passphrase` / `ihwt_pack`: openssl AES-256-CBC, PBKDF2 200 000,
the passphrase only via a file descriptor). Decrypt:
`openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -md sha256 -in <file>.zip.enc -out <file>.zip` –
or hand the `.zip.enc` to `10-Monitoring/patch_cycle_analysis.sh analyse --env`,
which decrypts and unpacks it into `env/`. Inside a git work tree `-t` is
refused unless git ignores the path.

**Patch scope since 2026-11-05.1** (for KA1182 / CPU / CSPU):

| File | Content |
|---|---|
| `30_inventory.txt` | + product versions of `inventory/registry.xml` (WLS / Forms & Reports / OPatch – selects the patch list) |
| `33_components.txt` | patch-relevant `comps.xml` components with version (DB client, Perl, OHS, WebGate, Coherence, ADF / JRF / OPSS / OWSM / EM / UMS / WebCenter / LibOVD / OAMCLIENT, Forms / Reports), `sqlplus -V`, `perl -v`, OHS / WebGate directories |
| `34_other_homes.txt` | `opatch lspatches -oh` of every other home of the central inventory (separate OHS / WebGate / DB client / old FMW homes) |
| `61_webserver.txt` routing (fix 2026-11-16.7) | Apache / OHS: global `<Location>` / mod_wl / ProxyPass routes are also written for every VirtualHost without own routes (Apache inheritance) – a TLS VirtualHost now shows `/forms` with `tls=yes` and its certificate; the global rows keep only the listeners no VirtualHost covers. Rated directives also list `WLProxySSL` / `WLProxySSLPassThrough`. Same function in the export (`export_forms_reports_conf.sh` / `.ps1` 2026-11-16.2) |
| `41_other_domains.txt` | the **other WebLogic domains** of the host, top level only (2026-11-16.6): found through `domain-registry.xml` / `nodemanager.domains` of every inventory home, the running servers and the sibling directories of the Forms domain; per domain name, version, production mode, Oracle home / `JAVA_HOME` of `setDomainEnv`, every server (listen address / port / cluster, pid / java / `-Xmx` when running), the application deployments and the products derived from them (BI Publisher, OAM, SOA …) – no configuration content; fact `Other WebLogic domains` |
| `43_ohs.txt` block `WebGate in the OHS instances` | WebGate (OAM agent) **configured** in an OHS instance of the domain (`webgate/config/ObAccessClient.xml`: agent id, security mode, OAM server, `webgate.conf` included, expiry of `aaa_cert.pem`) or only installed in the home – no passphrase; fact `WebGate configured (OHS)`; the patch analysis marks the WebGate bundle patch "active (OAM login)" |
| `35_opatch_prereq.txt` | inventory locks, owner / mode of the home and inventory, files not owned by the user, `.patch_storage` size, free space, the last apply / napply / rollback runs with their result |
| `44_forms_client.txt` | client JRE of the Forms users: JNLP `java version`, `formsweb.cfg` Java keys, `frmsal.jar` |
| `00_summary.txt` | + bundled JDK `oracle_common/jdk`, product versions, DB client, Perl, WebGate, `.patch_storage`, free space, locks, other homes, domain version, `openssl` / `ca-certificates` |

The process tree holds only the processes of the software owner (no command
lines of other users of the host).

Since 2026-10-29.1 also: the Reports / Forms components of `comps.xml`
(the home inventory OPatch uses – Reports binaries **without** these entries
are never patched, `00_summary.txt` then shows `!! Reports NOT REGISTERED`)
and the binary (`/proc/<pid>/exe`) of every WebLogic / Forms / Reports
process (`Processes outside ORACLE_HOME / JDK` – a process from another home
must be patched there).

Check the version first: `./collect_fmw_env.sh -V` (also the first line of
`00_summary.txt`) – it must match the version in the repository.

Result: `/tmp/fmw_collect_<host>_<timestamp>.zip.enc` (about 130 KB
without `--full`); `00_summary.txt` holds the key facts, every other file one
area (`10_os`, `20_java`, `30_inventory`, `31_opatch`, `33_components`,
`34_other_homes`, `35_opatch_prereq`, `40_domain`, `41_other_domains`, `43_ohs` (default
`index.html`, WebGate), `44_forms_client`, `45_licence`, `46_security` (domain secrets, realm, owner), `50_processes`, `51_forms_memory`, `60_net`,
`61_webserver` (Nginx / Apache / standalone OHS: routing, rated directives,
patch facts), `62_certificates`, `load/`, `70_logs`, `72_forms_crashes` + `dumps/` (Forms runtime crashes)). Runtime on the test host: about 90 s.

**Read-only:** writes only into the output directory (OPatch writes its usual
logs to `$ORACLE_HOME/cfgtoollogs` while it reads the inventory). Every
command runs under `timeout 600`.

**Secrets:** password elements, `<identifier>` content, `{AES}` values,
`userid=` / `authid=` / `password=` values, `user/password@` connect strings
and `-D…password=` arguments are replaced by `***MASKED***` before anything is
written (`ihwt_mask`, the same rules as the configuration export).
Host names, IP addresses and paths stay in the output – they are needed for
the analysis. Check the files before sending; never commit the output to a
repository.

## collect_ords_apex.sh

Third collector (2026-11-26): ORDS and APEX are not Forms & Reports, but they
run on many of these hosts. Read-only; runs as the ORDS owner (oracle).

```bash
./collect_ords_apex.sh -t /tmp                 # encrypted archive (passphrase asked twice)
./collect_ords_apex.sh --no-exec --no-encrypt   # files only, no ORDS program call
./collect_ords_apex.sh --ords /opt/ords --log-days 14
```

| Option | Meaning |
|---|---|
| `-t DIR` | base directory of the output (default `/tmp`) |
| `--no-exec` | do not run the ORDS program; by default `ords --version`, `ords config --db-pool <p> list --include-defaults` and `ords config user list` run read-only (a JVM for a few seconds, timeout 90 s, skipped below 512 MB available memory) |
| `--log-days N` | days of logs to aggregate (default 7) |
| `--ords DIR` | more ORDS homes / config directories (repeatable) when the discovery finds nothing |
| `--no-encrypt` / `--keep` | as `collect_fmw_env.sh` |

**Discovery** (`ihwt_ords_find` in `ihw_tools_lib.sh`): processes (`ords
serve` / `ords.war`, Tomcat `Bootstrap` with an ORDS web application,
WebLogic server with an ORDS deployment – config dir from `--config` /
`-Dconfig.url`), systemd units `*ords*` incl. template instances
(`ords@ords_1`), a bounded `find` for `global/settings.xml`, `ords*.war` and
the configuration layout before ORDS 22 (`defaults.xml`). Unpacked ORDS ZIPs
are listed as `software` / `software-used`.

| File | Content |
|---|---|
| `00_summary.txt` | facts: installations + modes, versions, Java, pools, features (installer choice 1–5), file users, web routes, APEX images, listen addresses, AJP / auth headers, requests + SQL endpoint hits of the log |
| `10_instances.txt` | `ords;id;mode;home;war;config;pid;unit;user;ports` + process arguments and `systemctl cat` / `show` per instance |
| `20_version.txt` | `version;…;jar|exec;<ver>` (jar names of `ords.war` and `ords --version`), `java;…` of the process / unit |
| `30_config.txt` | masked copies of `settings.xml` / `pool.xml` (Tomcat `server.xml`), `cfg;id;pool;key;value;source` from `config list` (passwords shown as `******` by ORDS), `user;…` (file-based users, roles only), `credfile;…`, `wallet;…` (file + mode – never copied) |
| `40_apex_images.txt` | `apex;dir;version;date;served by` – every `/i/` source (web server alias / root, `standalone.static.path`, Tomcat `webapps/i`, `find apex_version.txt`). The APEX version is only read from the images – no DB connect |
| `50_webtier.txt` | web server routes to ORDS / `/i/` (`IHWT_WT_HEAD` format) |
| `60_logs.txt` | last N days, aggregated: `access;id;day;requests;2xx;3xx;4xx;5xx;internal;external`, `endpoint;id;database_actions|rest_enabled_sql|database_api|graphql|landing|apex;hits;2xx`, `errors;id;file;day;count` + the last 50 error lines (masked) |
| `70_security.txt` | `listen;id;addr;loopback|network`, `feature;id;pool;sdw;restsql;dbapi;graphql;choice`, `authhdr;…` (fixed `Authorization` header in a route, value masked), `ajp;…` (Tomcat connector / `ajp://` / `JkMount`), `tomcat;…;version`, `tomcatusers;…`, `firewalld;…` |

`collect_fmw_env.sh` (2026-11-26.2) only shows the fact `ORDS / APEX` and
points to this collector. Windows: [`collect_ords_apex.ps1`](powershell/README.md#collect_ords_apexps1)
(2026-11-27, same files and line formats).

Fixes 2026-11-27 (2026-11-27.1, found while building the Windows twin): only
the JVM counts as an ORDS process (a shell whose command line mentions
`ords.war` no longer becomes an instance); `cfg;…` lines mask every key that
names a secret (`db.password` of an old `pool.xml` before the wallet); a
commented-out AJP connector is no finding and the AJP `secret=` is masked;
the route count no longer counts the empty end line.

## java_check_fmw.sh

Standalone version of `02-Checks/java_check.sh` + `07-Maintenance/domain_jdk_path.sh`
for customer hosts (2026-11-26) – after a JDK switch to a link, which part
still uses the old directory? Read-only, no library.

```bash
./java_check_fmw.sh                      # ORACLE_HOME / DOMAIN_HOME detected
./java_check_fmw.sh -o /app/oracle/mw -d /app/oracle/mw/user_projects/domains/fr_domain
```

| Section | Checks |
|---|---|
| 1 JDK of the configuration | `JAVA_HOME` of the shell, `oui/.globalEnv.properties` (WLST / OPatch), `setDomainEnv.sh`, `setNMJavaHome.sh`, `nodemanager.properties`, systemd units – missing (FAIL), link (OK) or versioned directory (WARN), version, Oracle JDK / OpenJDK |
| 2 bundled JDK `oracle_common/jdk` | real directory or replaced by a link / another JDK ("bent"), version (14.1.2: Oracle JDK 17), `bin/java` + `lib/server/libjvm.so` present, links inside (outside `legal/`), files changed after its `release` file, copies next to it |
| 3 Reports | `reports.sh` uses only `oracle_common/jdk` (another JDK path = edited by hand), engine `jvmOptions`, the `libjvm.so` loaded by the running `rwserver`, rwserver down |
| 4 running processes | Node Manager, WebLogic servers, Reports engines, `frmweb` – JDK, version, vendor; `LD_PRELOAD` / `LD_LIBRARY_PATH` of a running `frmweb` |
| 5 files with a JDK path | domain `bin/*.sh`, `nodemanager.properties`, `reports.sh`, Forms env files, `rwserver.conf`, Forms instance scripts, `startup.properties`, `oui/`, systemd units – variables resolved, missing JDK = FAIL, versioned directory = WARN, with file and line |

Summary "what to adjust"; exit 0 / 1 (warnings) / 2 (failures). Windows:
[`powershell/java_check_fmw.ps1`](powershell/README.md#java_check_fmwps1).
Used in the manual JDK switch:
[Java_wechsel_Kochbuch_de.txt](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/FormsReports_change_java/Java_wechsel_Kochbuch_de.txt)
steps 1.0 / 7.1.

## check_fix_libzrc_glibc.sh

The Reports QPR rebuilds `lib/libzrc.so.0` against the system glibc; on OL9
every later Forms relink (`frmweb`, `dejvm`, Forms QPR) fails with
`libzrc.so: undefined reference to dlsym@GLIBC_2.34` (MOS KB873815, Bug
38892485; background: [06-oracle_patch_forms_reports.md](../../09-Install/docs/06-oracle_patch_forms_reports.md)).
Standalone version of `_fix_libzrc_glibc` of `06-`.

```bash
./check_fix_libzrc_glibc.sh               # read-only check
./check_fix_libzrc_glibc.sh --show        # check + print the manual repair commands for this home (changes nothing)
./check_fix_libzrc_glibc.sh --apply       # repair (Forms / Reports of this home stopped)
```

- **Checks:** `lib/libzrc*` (the link `libzrc.so` -> `libzrc.so.0` – missing
  breaks the Forms XML tools; `libzrc.so_back` = Oracle's KB873815 workaround
  started), the GLIBC versions `libzrc.so.0` needs against `lib/stubs`, `ldd`
  of `frmweb` / `libfrmjapi.so.0` / `rwserver` / `dejvm` (static `frmweb` after
  the workaround, `dejvm` missing), Forms patches in `inventory/oneoffs` not in
  `opatch lspatches`, OPatch logs with the relink error (history: when).
- **`--apply`:** backup `libzrc.so.0.glibc_<ts>`, rebuild from `lib/libzrc.a`
  against `lib/stubs` (`dlsym@GLIBC_2.2.5`, restored on failure), create the
  missing link; refuses while a `frmweb` / `rwserver` of this home runs. The
  relink of `dejvm` / `frmweb` is printed, not run.
- **`--show`:** for a customer who repairs by hand – the same steps as
  commands for this home, one per line with `# Expected:`: stop check,
  backup, rebuild + `nm` check, link, (leftover oneoffs moved away), relink
  `dejvm` / `frmweb`, `ldd` check, the check run again, the way back.
- Needs `nm` / `readelf` (binutils), for `--apply` `ar` + `gcc`. Tested on the
  test host (check) and in an isolated copy of the home (repair).

## mos_patch_download.sh

Downloads all patches of a CSV list from My Oracle Support with
[getMOSPatch](https://github.com/MarisElsins/getMOSPatch) – per patch the
right platform and only the needed file, then `unzip -t` and SHA-256 of every
ZIP. Standalone like [`collect_fmw_env.sh`](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/tools/bash/collect_fmw_env.sh): bash + coreutils + Java +
python (only for the password terminal), no IHateWeblogic library.

### Place getMOSPatch on the host

1. On a machine with internet: download `getMOSPatch.jar` from the GitHub
   page above (Releases), copy it to the host – next to the script, into the
   target directory, or anywhere (`-j`).
2. Java 8 or newer (the Oracle Home's JDK is fine:
   `export JAVA_HOME=<ORACLE_HOME>/oracle_common/jdk` or the server JDK, or
   `--java <path>`).
3. **No `.getMOSPatch.cfg` to prepare:** getMOSPatch reads the platform /
   language from `.getMOSPatch.cfg` in the *current working directory*; the
   script writes one per patch directory (`<platform>;4L`, 4L = American
   English) from the CSV.
4. MOS account with download rights for the product (Extended Support for
   12.2.1.x patches). The user is `-u` / `$MOS_USER` or asked; the password
   is asked **once** (hidden) and typed into getMOSPatch through a pseudo
   terminal – never on a command line, never stored, masked in the log.
5. Outbound HTTPS to `updates.oracle.com`, the Oracle SSO
   `login-ext.identity.oraclecloud.com` and the Akamai download hosts
   (`*.oracle.com`). Behind a proxy: `--proxy host:port`, default
   `$https_proxy`. With TLS interception
   the company root CA must be in the `cacerts` of the Java used – see
   [certificates_trust_stores.md §6](../../80-FMW-Architecture/certificates_trust_stores.md).

```bash
# as any user with write access to the target directory (oracle is fine)
cd /oracle/install/cpu_okt2026
cp <repo>/70-Customer-Projects/tools/bash/mos_patch_download.sh .
cp <repo>/70-Customer-Projects/FormsReports12_patch_cpu_2026-10/patches_cpu_forms_reports_12c_oct2026.csv .
# getMOSPatch.jar placed here by hand
./mos_patch_download.sh -c patches_cpu_forms_reports_12c_oct2026.csv -d ./zip                      # plan only
./mos_patch_download.sh -c patches_cpu_forms_reports_12c_oct2026.csv -d ./zip -u me@example.com --apply
./mos_patch_download.sh -c patches_cpu_forms_reports_12c_oct2026.csv -d ./zip --only 39888613,39600813 --apply

# patch list of the library (14.1.2) on a host without the library - result in
# the PATCH_STORAGE layout (column dir), then rsync to the target host:
./mos_patch_download.sh -c patches_fmw.csv -d /share/patch_storage --all --apply

# control file from the TARGET host (library: only what it misses) - also for
# mos_patch_download.ps1 on a Windows PC when the host itself has no MOS access:
#   target host:  09-Install/04-oracle_pre_download.sh --offline-list
#   PC:           .\mos_patch_download.ps1 -Csv offline_download_<ts>.csv -Dir D:\patch_storage -All -Apply
#   back:         scp -r D:\patch_storage\* oracle@<host>:<PATCH_STORAGE>/
```

| Option | Meaning |
|---|---|
| `-c FILE` | patch list (CSV, format below) |
| `-d DIR` | target directory; one sub-directory per patch: `DIR/<dir>/p<patch>_*.zip` (`<dir>` = column `dir`, default `<patch>`) |
| `-j JAR` | getMOSPatch.jar (default: `./`, then `DIR/`, then the script directory) |
| `-u USER` | MOS user (default `$MOS_USER`, else asked) |
| `--all` | also the rows with `required=optional` |
| `--only N,N` | only these patch numbers (optional rows included) |
| `--steps S,S` | only rows with these values in column `step` (optional rows included) – the library passes its roles (`spb,wls,jdk,…`) |
| `--password-stdin` | read the MOS password from the first line of stdin instead of asking (caller: `09-Install/04-oracle_pre_download.sh --mos`); needs `-u` / `$MOS_USER` |
| `--java JAVA` | Java binary (default `$JAVA_HOME/bin/java`, then `java` in `PATH`) |
| `--proxy H:P` | HTTPS proxy for getMOSPatch (default: `$https_proxy` / `$HTTPS_PROXY`) |
| `--apply` | download – without it the plan is printed (which patch, platform, file, already present) |

Checks first: Java, jar, `unzip`, `sha256sum`, python (`python3`, then
`/usr/libexec/platform-python` – always present on OL8 / OL9; without python
getMOSPatch asks for user / password itself for every patch), free space
(WARN below 15 GB – a full 12c CPU set has ~6 GB). A ZIP already present is
skipped – a second run only loads what is missing. Up to 3 attempts per
patch and platform.

Result: `DIR/<dir>/…zip`, `DIR/patches_sha256.txt` (compare with the
SHA-256 shown on the MOS download page), `DIR/patches_sha256.csv`
(`patch;step;file;sha256;aru` – to fill the `sha256` / `aru` columns after an analysis; `aru` = Unique Patch ID from `<patch>/etc/config/inventory.xml` of the ZIP, also shown in the check line),
`DIR/mos_patch_download_<ts>.log`.
Exit code 0 = all required patches present, 1 = an optional one missing or a
SHA-256 / ARU differs from the list, 2 = a required one missing / damaged ZIP /
prerequisite missing.

### CSV format

`;`-separated, `#` = comment, one header line:

```
patch;platform;file_regexp;required;step;description[;dir[;sha256[;aru]]]
40129641;2000P;p40129641_122140_Generic\.zip;yes;6;WLS Stack Patch Bundle 12.2.1.4.261007
39888613;226P;p39888613_1221190_Linux-x86-64\.zip;yes;8;Oracle Forms QPR 12.2.1.19
40186682;226P;p40186682_.*_Linux-x86-64\.zip;yes;4;JDK 8u511 (file name not fixed)
```

| Column | Meaning |
|---|---|
| `patch` | MOS patch number |
| `platform` | MOS platform code; alternatives with `\|` (`2000P\|226P`) are tried in order when MOS has no file for the first |
| `file_regexp` | Java regex of the **whole file name** (incl. `\.zip`); empty = all files of the platform. The script strips a trailing `\.zip` before passing it to getMOSPatch – getMOSPatch compares with `String.matches()` against the file name **without** `.zip` (`p38832179_122140_Linux-x86-64`), a regexp ending in `\.zip` never matches there (checked in the class, 2026-10-28) |
| `required` | `yes` or `optional` (only with `--all` / `--only`) |
| `step` | step of the cookbook that applies the patch (information only); in the library list [`09-Install/download/patches_fmw.csv`](https://github.com/gpipperr/IHateWeblogic/blob/main/09-Install/download/patches_fmw.csv) the **role** (`spb`, `wls`, `jdk`, … – [download/README.md](../../09-Install/download/README.md)), filter with `--steps` |
| `description` | free text |
| `dir` | optional: target below `-d` (default `<patch>`) – e.g. `patches/40289362`, `client/jdk/35702194`, `database/cvu`, `database/mrp/40196156` |
| `sha256` | optional: SHA-256 of the analysed file – **soft check**: a different value is a WARN (exit 1), never a FAIL – Oracle re-releases patches under the same number (the JDK patch with every update); `unzip -t` stays the hard check |
| `aru` | optional: Unique Patch ID (ARU) of the analysed build (`<unique_patch_id>` in `<patch>/etc/config/inventory.xml` = "Unique Patch ID" of `opatch lsinventory`) – **soft check** like `sha256`: a new build of the same patch number has a new ARU → WARN (exit 1). Stays empty for ZIPs without an OPatch inventory (Stack Patch Bundle, OPatch, JDK, CVU) – there the ARU is only in the MOS download link |

Platform codes (checked 2026-10-22):

| Code | Platform |
|---|---|
| `226P` | Linux x86-64 |
| `2000P` | Generic (all platforms – most FMW bundle patches) |
| `233P` | Microsoft Windows x64 (64-bit) |
| `46P` | Linux x86 (32-bit) |
| `541P` | Linux ARM 64-bit |

All codes of a patch: in an empty directory without `.getMOSPatch.cfg`
`java -jar getMOSPatch.jar patch=<nr> reset=yes` – getMOSPatch lists the
platforms / languages the patch exists for and writes a new
`.getMOSPatch.cfg` there.

### Troubleshooting

| Message | Cause / action |
|---|---|
| `No files available` / `There's nothing to download!` | no file for this platform – check the code (`reset=yes`), or the regexp does not match the file name (without `.zip`!); remove the regexp and look at the offered list |
| `Invalid credentials` | MOS user / password wrong, or the account is locked – log in once in the browser |
| `ERROR: …403…` / no download right | the MOS account (CSI) has no support / Extended Support for the product |
| `PKIX path building failed` | TLS interception – company root CA into the Java `cacerts` (see above) |
| hangs at the start | no outbound HTTPS – proxy (`--proxy`) or firewall |
| `unzip -t` FAIL | download broken – delete the ZIP, run again (skips the good ones) |

Live-tested 2026-10-28 on the test host (OL9, Java 21, getMOSPatch from the
patch repository): `--only 38832179` → ZIP, `unzip -t`, SHA-256 OK; password
not in the log. 2026-10-30 (version 2026-10-30.1): [`patches_fmw.csv`](https://github.com/gpipperr/IHateWeblogic/blob/main/09-Install/download/patches_fmw.csv) with
`--password-stdin --only 39726399,39600348` → `patches/<nr>/`, digests equal
to the CSV; wrong digest → WARN / exit 1, damaged ZIP → FAIL / exit 2; called
by `04-oracle_pre_download.sh --apply --mos` (all present, plumbing).

## fmw_patch_env.sh

Replaces the hand-edited `export` block **VORAUSSETZUNGEN** of the manual
patch cookbooks (`Patch_Kochbuch_*_de.txt`): detects the values on the host
and sets them. Standalone like the other tools.

```bash
cd /oracle/install/cpu_okt2026                 # base directory of the patch run
./fmw_patch_env.sh                             # show only (a script cannot set variables of its caller)
. ./fmw_patch_env.sh                           # SOURCED: exports the variables into this shell
. ./fmw_patch_env.sh --apply                   # + creates the directories, writes ./patch_env.sh
. /oracle/install/cpu_okt2026/patch_env.sh     # 2nd terminal / new login: same values
```

| Variable | Detected from |
|---|---|
| `ORACLE_HOME` | `-o`, `$ORACLE_HOME`, running WebLogic (`-Dweblogic.home`), default paths (`/oracle/product/mw`, `/u01/app/oracle/fmw` …) |
| `DOMAIN_HOME` | `-d`, `$DOMAIN_HOME`, `$ORACLE_HOME/domain-registry.xml` (WARN with more than one domain), running AdminServer |
| `INV_PTR` / `INVENTORY` | `/etc/oraInst.loc`, else `$ORACLE_HOME/oraInst.loc`; `inventory_loc` |
| `JDK_LINK` / `NEW_JDK_BASE` | `JAVA_HOME` of `$ORACLE_HOME/oui/.globalEnv.properties` (the JDK of OPatch and the servers) / its parent |
| `JDK_HOME`, `JAVA_HOME` | = `JDK_LINK` – the cookbook steps use `JDK_HOME`; since 2026-11-03 set by the script and written to `patch_env.sh` (before, an empty `JDK_HOME` in a new shell made the `ps \| grep` check of step 4 match every process) |
| `PATCH_DIR` / `STAGE` / `LOGDIR` | `-b` (default: current directory) + `/zip`, `/stage`, `/stage/logs` – `PATCH_DIR` = the `-d` of [`mos_patch_download.sh`](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/tools/bash/mos_patch_download.sh) |
| `BACKUP` | `-k`; default `<prefix>/backup/<name>` for `<prefix>/install/<name>` (cookbook layout), else `<base>/backup` |

Shown as well (the cookbook decides on them): JDK build and link or real
directory (step 4.4 variant a / b), bundled JDK `oracle_common/jdk` (4.7),
OPatch version, glibc (Forms before Reports QPR from 2.34), OHS instances
(step 9), number of ZIPs in `PATCH_DIR`, running WebLogic / Forms / Reports
processes, free space of `STAGE` / `BACKUP`.

FAIL (rc 2): Oracle Home, domain, inventory or JDK not found, JDK inside
`ORACLE_HOME` (KB175049), base directory inside the Oracle / Domain Home.
WARN (rc 1): `BACKUP` on the file system of `ORACLE_HOME`, more than one
domain, run as root. Read-only without `--apply`; with it only the four
directories and `patch_env.sh` in the base directory are created.
Tested 2026-10-29 on the 14c test host (executed, sourced, `--apply`).

## update_tools_from_git.sh

Keeps `$ORACLE_BASE/tools` current at the customer – no git clone, no manual
unzip over the old directory (2026-11-19). Lies in the tools directory and
works on that directory.

```bash
$ORACLE_BASE/tools/update_tools_from_git.sh            # show: installed -> repository (exit 1 = updates)
$ORACLE_BASE/tools/update_tools_from_git.sh --apply    # replace / unpack, install setdb
$ORACLE_BASE/tools/update_tools_from_git.sh --zip /tmp/ihw_customer_tools_linux.zip [--apply]   # offline
```

| Step | What happens |
|---|---|
| Download | the Linux ZIP + `.sha256` from the repository (branch `main`, the documented link; `--url` / `IHW_TOOLS_URL` for a mirror) with `wget --no-check-certificate`, `curl -fsSLk` when there is no wget – customer networks often intercept TLS with their own CA. The SHA-256 proves a complete transfer, not the origin. Proxy: `https_proxy` from the environment |
| Check | SHA-256 against the `.sha256`, `unzip -t`, `tools/VERSIONS.txt` must be in the ZIP |
| Compare | per file of `VERSIONS.txt`: `changed` (version installed → repository), `new`, current; a **locally newer** version (test / maintainer host) is kept – never a downgrade; files not in the ZIP (`patch_install.ini`, own scripts) stay as they are ("local only"). `ihw_shell_env.sh` is compared with the **installed** `~/.bashrc.d/ihw_env.sh`; a template still in the tools directory is reported for removal. Hints: a second switcher copy in `~/.bashrc.d`, no `bashrc.d` loop in `~/.bashrc` (never edited) |
| `--apply` | backup of every replaced file to `tools/backup/tools_<ts>/` (incl. the old `ihw_env.sh` – not into `~/.bashrc.d`, everything there is sourced; the newest 3 are kept), then each file as a temp file + `mv` (new inode – the running script, also this one, keeps its old copy, so it can update itself); `~/.bashrc.d` (700) / `ihw_env.sh` (644); template `ihw_shell_env.sh` deleted; `~/.ihw_env.conf` untouched. Ends with "Bitte ab- und neu anmelden" when `setdb` changed |

Exit 0 = up to date / applied, 1 = updates available, 2 = error. Not as
root. Windows: [update_tools_from_git.ps1](powershell/README.md#update_tools_from_gitps1) (same, without `setdb`). Road map: [Start_beim_Kunden_kochbuch_de.txt](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/Start_beim_Kunden_kochbuch_de.txt)
step 2 (first `setdb` install with `--zip`) and step 7 (update). Tested
2026-11-19 in a scratch copy with a fake `HOME`: old tools state → read-only
(exit 1) → `--apply` incl. self-update → second run "nothing to do"; download
from GitHub with wget and with curl only.

## ihw_shell_env.sh

Environment switcher for the oracle user, after the model of `setdb` in
[OraBashShell .profile](https://github.com/gpipperr/OraBashShell). It
changes **only the current shell** – no installation file, no
`environment.conf` of the library (that one is switched with
`00-Setup/detect_env_conf.sh --select`).

**Install** (as oracle, also on customer hosts – the file is standalone):
`update_tools_from_git.sh --apply` does it and removes the template from the
tools directory ([above](#update_tools_from_gitsh)); by hand:

```bash
mkdir -p ~/.bashrc.d
chmod 700 ~/.bashrc.d
cp ihw_shell_env.sh ~/.bashrc.d/ihw_env.sh
grep -n 'bashrc.d' ~/.bashrc
# Expected: the OL9 default loop "for rc in ~/.bashrc.d/*" (else add it)
```

Then open a new shell. On the test host `09-Install/03-root_user_oracle.sh`
does the same ([doc 5b](../../09-Install/docs/03-root_user_oracle.md)).
The first start detects the homes and writes `~/.ihw_env.conf` (mode 600,
editable): inventory (`/etc/oraInst.loc` → `inventory.xml`, removed or
missing homes skipped) plus `/etc/oratab`. A FMW home has
`wlserver/server/lib/weblogic.jar`; its domains come from
`domain-registry.xml`, its JDK from `oui/.globalEnv.properties`. A DB home
has `bin/oracle` + `bin/sqlplus`; its SIDs come from `/etc/oratab` and the
running `ora_pmon_*` processes; `ORACLE_BASE` from `bin/orabase`.

**Use** – `setdb`, `setfmw` and `setfw` show the same menu (live, test host):

```
    Current environment :  login values
-----------------------------------------------------------
  FMW
      1 ---> -  (home only)         Home: /u01/app/oracle/fmw
      2 ---> fr_domain              Home: /u01/app/oracle/fmw
-----------------------------------------------------------
  DB
    OraDB19Home1Patched            /u01/app/oracle/product/19.30.0/db_home1
      3 ---> -  (no SID)
    OraDB19Home_19_33_0            /u01/app/oracle/product/19.33.0/db_home1
      4 ---> FMWCDB
      5 ---> -  (no SID)
-----------------------------------------------------------
      t ---> tools                (cd to the tools directory, 2t = entry 2 + tools)
      c ---> clear environment    (back to the login values)
      h ---> help                 (aliases / functions / tools / variables)
      q ---> quit                 (nothing changed)
   Selection [1]:
```

**Tools:** `t` (also `setdb t`, `cdt`) changes to the tools directory and keeps
the environment; `2t` (also `setdb 2t`) selects entry 2 first. `h` lists the
tools that exist there, with one line each. `status.sh`, `show_log.sh`,
`show_errors.sh` and `show_all_logs.sh` use the domain selected here, see
[the operation tools](#set_script_envsh-and-the-operation-tools).

The tools directory (`IHW_TOOLS_DIR`, in the PATH, stays after `setdb c`) is
searched at login and after a selection:
1. `IHW_TOOLS_DIR` from the environment or as a line in `~/.ihw_env.conf` (survives
   `ihwenv_configure`);
2. `$ORACLE_BASE/tools`;
3. `tools` above a known home (`/u01/app/oracle/fmw` → `/u01/app/oracle/tools`,
   `/oracle/product/mw` → `/oracle/tools`), the base of a DB entry;
4. `/u01/oracle/tools`, `/u01/app/oracle/tools`.

Every DB home gets one line per SID **and always one `(no SID)` line**
(OPatch / work on the home without `ORACLE_SID`), the same idea as
"home only" for FMW; the homes in inventory order, each under a header
with its **home name** (`install/orabasetab`, else the inventory) and path. `setdb 2` selects directly, `*` marks the active entry, `q` or an invalid
choice changes nothing.

Where the homes come from (`ihwenv_configure`, every path once – symlinks
and a trailing `/` only for the comparison, the registered spelling is
kept for OPatch):
- the central inventory (`/etc/oraInst.loc`), entries not `REMOVED`;
- **further inventories** named in `<home>/oraInst.loc` – a DB home
  installed with its own `-invPtrLoc` or by another team is not in the
  FMW inventory;
- `/etc/oratab`;
- the standard locations `/u0?/app/*/product/*/*`, `/oracle/product/*/*`,
  `/opt/oracle/product/*/*`, `$ORACLE_BASE/product/*/*` (only directories
  with `bin/oracle`) – a DB home **without SID** is in no oratab and
  without them it would not be listed (customer, 2026-11-03).

What was found but not listed is written as `# skipped: <home> (reason)`
into the cache and shown after the run: directory missing, client home (no
`bin/oracle`), neither FMW nor DB. A home still missing: add the line by
hand to `~/.ihw_env.conf` (`IHW_DB_ENV+=("- <home> <base>")`).

| Entry | Sets | PATH (in front of the login PATH) |
|---|---|---|
| FMW domain | `ORACLE_HOME` `WL_HOME` `DOMAIN_HOME` `DOMAIN_NAME` `JDK_HOME` `JAVA_HOME` `WLST` `NM_HOME` `FMWCONFIG` `FORMS_INSTANCE` `FORMS_APP_CONF` (formsweb.cfg, default.env) `REPORTS_APP_CONF` (rwservlet.properties, cgicmd.dat) `REPORTS_SERVER_CONF_DIR` (rwserver.conf) `REPORTS_TOOLS_CONF_DIR` (rwbuilder.conf); unsets `ORACLE_SID` | `$DOMAIN_HOME/reports/bin` (`rwrun.sh`, `rwclient.sh` – the domain wrappers, plain `$ORACLE_HOME/bin/rwrun` lacks the Reports env), `$DOMAIN_HOME/bin`, `$JAVA_HOME/bin`, `$ORACLE_HOME/oracle_common/common/bin` (FMW `wlst.sh`), `$ORACLE_HOME/bin`, `$ORACLE_HOME/OPatch` |
| FMW home only | the same without the domain variables (patching, OPatch) | without the two domain directories |
| DB (SID or `-`) | `ORACLE_HOME` `ORACLE_SID` (unset for `-`) `ORACLE_BASE`; removes all FMW variables | `$ORACLE_HOME/bin`, `$ORACLE_HOME/OPatch` |
| `c` | back to the login values (saved at the first `setdb` call), all switcher variables removed | login PATH |

Never changed: `TNS_ADMIN`, `NLS_LANG` (one Oracle Net directory for all
processes).

`SQLPATH` / `ORACLE_PATH` (sqlplus / SQLcl: personal `login.sql` and DBA
scripts in `~/sql`, as in OraBashShell) are set **only by a DB entry**.
FMW entries and `c` remove them, and a fresh login has none: a `login.sql`
disturbs `datapatch`, `catcon` and `utlrp` and every scripted sqlplus call.
So `setdb c` before patching a DB home by hand. The IHateWeblogic library
unsets both in every script anyway. The login PATH is cleaned of the entries of the login
`ORACLE_HOME` / `JAVA_HOME` before the new entries are put in front, so
PATH does not grow (live: 8 switches, length 156 / 240 / 121 constant).

Helpers: `whichenv`, `ihwenv_configure [-f]`, `wlst` (FMW `wlst.sh` from
`oracle_common` – never `wlserver/common/bin/wlst.sh`, it lacks `createCred`,
`grantAppRole` & co.; without arguments it starts in `$DOMAIN_HOME`), `cdoh`,
`cddh`, `cdcfg`, `cdnm`, `cdt`, `cdlog [server]` (server logs; with a DB entry the
ADR `diag` directory + `adrci show homes`). A function `myprompt` defined in
`.bash_profile` is called after each switch (as in OraBashShell).

Non-interactive shells (scp, sftp, cron, `bash -c`) load nothing and print
nothing (first line `[[ $- == *i* ]] || return`). Tested 2026-11-03 on the
14c test host (isolated `HOME` + real login shell): all four entries,
`c`, `h`, invalid input, PATH length, nested shell, `wlst` start directory.

## clone_check_fmw.sh

Standalone, read-only version of `02-Checks/clone_check.sh` for customer
hosts (12.2.1.x and 14.1.2): could this installation become a **golden
image** / be moved to another host? Target: everything internal on
`127.0.0.1`, only the web tier (OHS / Apache / Nginx) and the certificate
carry the host name. Background and recipe:
[clone_golden_image.md](../../80-FMW-Architecture/clone_golden_image.md).

```bash
cp clone_check_fmw.sh /tmp/ && cd /tmp && chmod +x clone_check_fmw.sh
./clone_check_fmw.sh                     # auto-detect ORACLE_HOME / DOMAIN_HOME
./clone_check_fmw.sh -d /oracle/user_projects/domains/fr_domain -t /tmp
./clone_check_fmw.sh --config            # + under each finding: file and lines to change
```

**`--config`** (2026-11-09) shows under each FIX / STEP the configuration
file with its full path and the lines (with line number) that hold the own
host name / IP or the setting to change – e.g. the `<url>` line of a JDBC
descriptor, `<listen-address>` in `config.xml`, `ListenAddress=` in
`nodemanager.properties`, `server_name` of the Nginx, the `HOST` in
`tnsnames.ora` (all `HOST` lines). A missing setting is named instead
("no such line: no `<unicast-listen-address>` = automatic …", no
`REPORTS_JVM_OPTIONS`, no `WLS_REPORTS` block in `setUserOverrides.sh`); an
empty listen address shows the `<name>` line of its `<server>` block plus the
WLST command. At most 8 lines per file (then "… n more"); `{AES}` values and
password values are masked. Without `--config` the output is as before.

| Section | FIX (before an image) | STEP (after cloning) / INFO |
|---|---|---|
| 1 listening sockets (`ss`) | java / `rwserver` socket on all interfaces or the host IP | web tier (`httpd`, `nginx`) by design; `frmweb` (no bind option); Coherence remainder; multicast discovery |
| 2 `config.xml`, `nodemanager.properties` | listen address not loopback, SSL listen port on, Coherence unicast not `127.0.0.1` | – |
| 3 Reports | no `ORBServerHost=127.0.0.1` in `reports.sh` / `setUserOverrides.sh` | discovery port / server name per clone |
| 4 host name / IP in `$DOMAIN_HOME/config` and `bin/*.sh` | unknown file; own host name in a domain script; `ADMIN_URL` of `bin/*.sh` or of the shell not on `localhost` (2026-11-10.2 – a clone's `stopWebLogic.sh` would address the source AdminServer); `AdminURL` of `servers/*/data/nodemanager/startup.properties` not on `localhost` (2026-11-10.3 – managed server in independence mode, EM shows it shut down) | JDBC / OPSS (DB host), OHS config; RCU repository local (cloned along) or **external** (own prefix per clone) |
| 5 machine identity | – | domain key travels with the clone, stored WLST credentials |
| 6 by design | – | OHS `ServerName` / `Listen`, Apache / Nginx `server_name` + certificate, `tnsnames.ora` hosts |

Nothing is changed: for SSL / Coherence the needed WLST online commands are
printed at the end (run them with the AdminServer up, then restart the
managed servers). Needs `ss`; python (`python3`, else
`/usr/libexec/platform-python`) to parse `config.xml` – without it section 2
is reported as not checked. As `oracle` only the own sockets show a process
name; as root all. Exit 0 = clone-capable, 1 = items to fix, 2 = no domain.
Log: `<-t>/clone_check_<host>_<ts>.log` (contains host names / IPs – keep it
out of repositories). Tested 2026-10-29 on the 14c test host: same verdict
as `02-Checks/clone_check.sh` ("yes").

## check_disk_space.sh

Where is the space of the **local** disks? Read-only – deletes nothing, prints
the clean command per finding. Network file systems (NFS, CIFS, sshfs … – e.g.
the NFS-mounted ZFS patch archive) are read from `/proc/self/mounts` and
**never scanned**, also not when they are mounted below a local directory
(`du -x` / `find -xdev` per local file system).

```bash
sudo ./check_disk_space.sh                 # as root: complete picture
sudo ./check_disk_space.sh --big 1000      # single files >= 1 GB only
sudo ./check_disk_space.sh --min 500       # tree: directories >= 500 MB only
```

| Option | Meaning |
|---|---|
| `--min MB` | smallest directory in the usage tree (default 100) |
| `--big MB` | smallest single file in section 5 (default 500) |
| `--top N` | at most N entries per tree level (default 15) |
| `-t DIR` | directory of the report file (default `/tmp`) |

Sections:

1. **File systems** – local (scanned, WARN >= 85 %, FULL >= 95 %) and network
   (listed, not scanned).
2. **Usage tree** – 2 levels below each local mount point; mount points of
   other file systems are marked. df used much larger than the du sum
   (> 1 GB and > 5 %) = hidden space: deleted but open files (section 4) or
   files written **under** a mount point before the NFS / disk was mounted –
   the bind-mount command to see them is printed.
3. **Known space eaters**, largest first, each with its clean command: dnf
   cache, journal, rotated logs, old kernels, crash / core dumps (our
   `core_pattern` writes to `/var/tmp/core`), `/tmp`, `/var/tmp`; Oracle homes
   of the central inventory – **in use** (process, `/etc/oratab`, registered
   domain) or **not in use** (old home after an out-of-place patch →
   `deinstall`), `.patch_storage` (`opatch util cleanup`), AutoUpgrade
   `patchdir` (gold image, base ZIP), ADR (`adrci purge`), audit files, FRA,
   unlinked JDKs below `$ORACLE_BASE/java`, CVU home, OUI leftovers,
   `PATCH_STORAGE` (→ `07-Maintenance/patch_storage.sh clean`), WebLogic logs
   / tmp / cache, IHateWeblogic logs and config backups. Locations come from
   the environment, the repository's `environment.conf` (when run from the
   repository) or the defaults.
4. **Deleted but still open files** (`/proc/*/fd`) – the space comes back only
   when the process ends.
5. **Single files >= `--big`** with date and owner.

Exit code: 0 = all local file systems < 85 %, 1 = one >= 85 %, 2 = one >= 95 %.
Runtime on the test host (100 GB disk, 92 GB used): about 40 s.

## export_forms_reports_conf.sh

Exports the customer-specific configuration of an **existing** Forms &
Reports environment (12.2.1.x or 14.1.2) into one archive – the input for
the rebuild with the 14c library. Read-only on the host, writes only below
`-t OUTDIR`. Step 1 of the migration; the import into the library is
`00-Setup/customer_conf_import.sh` – whole process:
[00-transfer_customer_settings.md](../../09-Install/docs/00-transfer_customer_settings.md).

```bash
# as the software owner (oracle), not root - from the unpacked tools ZIP
# (the script needs ihw_tools_lib.sh next to it)
cd $ORACLE_BASE/tools
./export_forms_reports_conf.sh                      # auto-detect, encrypted archive (passphrase asked twice)
./export_forms_reports_conf.sh -o /oracle/product/mw -d /oracle/user_projects/domains/fr_domain
./export_forms_reports_conf.sh --masked             # passwords masked, not encrypted – for analysis
```

| Option | Meaning |
|---|---|
| `-o DIR` / `-d DIR` | Oracle Home / domain home (default: environment, `domain-registry.xml`, running process, known paths – as `collect_fmw_env.sh`) |
| `-t DIR` | output directory (default `/tmp`); inside a git work tree it is **refused** unless git ignores the path |
| `--masked` | mask passwords in every file, archive not encrypted |
| `--no-fonts` | list the font files only, do not copy them |
| `--keep` | keep the unpacked staging directory (delete it yourself – customer data) |
| `--jar-dir DIR` | directory with client jars that `archive=` names by a **URL path** outside `/forms/java` (e.g. `/frmopt/lib/x.jar`, served by another web location) – searched by file name, by the path below the first URL segment (`lib/x.jar`) and by the full path, repeatable. Since 2026-11-26.1 the export first looks in the document roots and aliases of the web servers on the host (OHS `DocumentRoot` / `Alias` of every instance – default `instances/<n>/htdocs` –, Apache, Nginx `root` / `location … alias`); `--jar-dir` is needed only when they do not hold the jar. Not found: listed as `URL_PATH` in `ihw_import/jars.txt` |

`--no-load` / `--load-days` / `--rw-auth` moved to `collect_fmw_env.sh` with
the load profile and the HTTPS listener certificates (2026-11-16.1); the
export accepts them and prints a note. `ihw_import/certificates.txt` keeps the
signers of the customer jars.

**Load profile** (`load/` of `collect_fmw_env.sh` since 2026-11-16.3, before
of the export since 2026-11-04.4) – **only counted values**, no
log line leaves the host (access logs hold client addresses, user names and,
with GET report calls, passwords):

| File | Content |
|---|---|
| `forms_starts.csv` | `date;section;starts` – `frmservlet?config=…` with HTTP 2xx from the WLS_FORMS access logs |
| `forms_traffic.csv` / `forms_hourly.csv` | `date;requests;lservlet;http_5xx;avg_ms` (avg only with `time-taken`) / `hour;starts` |
| `now.txt` | `frmweb` processes + RSS, Reports engine processes, uptime, load average |
| `reports_requests.csv` | `date;command;requests;http_5xx` from the WLS_REPORTS access logs (command = `getserverinfo`, `showjobs`, report run …, no parameters) |
| `reports_<server>_serverinfo.xml`, `reports_jobs.csv` | `getserverinfo` and the past job queue (`server;id;report;status;started_epoch;seconds` – no owner, no parameters) of every **running** Reports server; a not running in-process server is not asked (the request would start it) |
| `host_sar.csv` | `date;cpu_avg;cpu_peak;mem_avg` from `/var/log/sa` (sysstat), if present |

**Output:** `ihw_export_<host>_<ts>.zip.enc` (+ `.sha256`; `.zip` with
`--masked`; `.tar.gz` if `zip` is missing). Decrypt:

```bash
openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -md sha256 -in ihw_export_<host>_<ts>.zip.enc -out ihw_export_<host>_<ts>.zip
```

### Passwords – two modes

The configuration files contain passwords: `cgicmd.dat` `userid=` /
`authid=`, `default.env` / env files, `rwserver.conf` `<identifier>` (clear
until the Reports server encrypts it), `{AES}` values in `config.xml`, data
source passwords. Choose the mode **before** the run:

| | Default: **encrypted** | `--masked` |
|---|---|---|
| Passwords in the archive | **included** (1:1 copies – needed for the rebuild) | replaced by `***MASKED***` in every text file (also in the derived `ihw_import/` files) |
| Archive | AES-256 encrypted (`.zip.enc`) | not encrypted (`.zip`) |
| Use | input for the 14c rebuild / later import | analysis, may be sent by mail / ticket after a look at it |
| Needs | `openssl`, a terminal for the passphrase | – |

**Passphrase (encrypted mode):**
- Asked **at the start**, before the minutes of collecting, so you do not
  have to wait for it. It is asked twice and hidden (`read -s`); empty or
  unequal input is asked again.
- Without a terminal (cron, pipe, `ssh host cmd` without `-t`) the script
  **refuses** to run. Use `--masked` there, or start it in an interactive
  session.
- It is handed to `openssl` over a file descriptor (`-pass fd:3`), **never on
  the command line**, so it is not visible in `ps` / `/proc/<pid>/cmdline`.
  It is not written to any file, and the variable is cleared right after
  the encryption.
- Encryption: `openssl enc -aes-256-cbc -pbkdf2 -iter 200000 -md sha256
  -salt`. PBKDF2 with 200 000 iterations makes guessing a weak passphrase
  expensive, but it does not make a weak passphrase strong. Use a long one
  (e.g. 4–5 random words), because the archive holds the customer's
  passwords.
- **Forgotten passphrase = archive lost**: there is no recovery key. Give
  the passphrase to the recipient on a **different channel** than the file
  (phone / messenger vs. mail / share) and keep it in the password safe
  together with the customer entry.
- `openssl` of OL8 / OL9 (1.1.1 / 3.x) supports `-pbkdf2`. Decrypt with the
  same parameters (command above, also printed at the end of the run); on
  Windows with the `openssl.exe` of Git for Windows.

**Masking (`--masked`):**
- The same rules as `collect_fmw_env.sh`, plus `<identifier>…</identifier>`,
  `name="…password…" value="…"` (XML attributes) and `dbpassword=`.
- `raw/` files are masked while they are copied. Every other text file
  (`ihw_import/`, reports, dependency lists) is masked again before packing,
  because these files quote configuration lines. A first version left a
  `authid` value in `ihw_import/cgicmd.dat.customer_keys`; that is fixed and
  tested.
- Binary files (fonts, jars) are copied unchanged – they hold no passwords.
- Masking is pattern based: a password in an unusual place (own variable
  name, comment) can stay. Look through the archive before sending it.

**In both modes:**
- `secrets_locations.txt` lists **where** secrets are (`file:line:keyword`,
  never the value). With it you know which files to look at, and which
  passwords the rebuild needs.
- `umask 077`: the staging directory and the archive are readable for the
  running user only.
- The **staging directory** (`<OUTDIR>/ihw_export_<host>_<ts>/`) holds the
  files **unencrypted**: in clear text in the default mode, masked with
  `--masked`. It is removed after packing, unless `--keep` is given (the
  script then reminds you to delete it).
- **Abort** (Ctrl-C, `kill`, SIGHUP when the SSH session drops, error
  exit): an exit trap removes the staging directory and a half-written or
  still unencrypted archive, then prints `ABORTED (rc …)`. With `--keep`
  the staging directory is kept and the message names it. Since version
  2026-11-03.2; tested with SIGINT / SIGTERM in both modes. Only a
  `kill -9` or a power loss leaves it behind – then delete it by hand:
  `rm -rf /tmp/ihw_export_<host>_<ts>`.
- The archive itself never goes into git (see "Customer data" below). After
  the rebuild delete it in `/tmp` and on every copy, and keep the
  passphrase only as long as the archive exists.

| Part | Content |
|---|---|
| `00_report.txt` | versions, paths, Forms sections, Reports servers, customer jars, fonts, source dirs, warnings, what goes where |
| `raw/domain/`, `raw/oracle_home/`, `raw/other/` | 1:1 copies below their original path: `formsweb.cfg` + every `envFile`, `Registry.dat`, `webutil.cfg`, `*.res`, jnlp files; per Reports server (standalone + in-process) `rwserver.conf`, `rwnetwork.conf`, `rwservlet.properties`, `cgicmd.dat`; ReportsTools `uifont.ali`, PPD, AFM; `reports.sh`, `setUserOverrides.sh`, `config.xml`, `jps-config-jse.xml`, `tnsnames.ora` / `sqlnet.ora`, web tier: every configuration file of Nginx / Apache (+ `mod_wl`) / OHS incl. all includes |
| `ihw_import/` | proposals laid out for the library (nothing applied): `formsweb.cfg.default_overrides` / `.sections`, `default.env.customer_keys` (`FORMS_PATH_CUSTOMER`, `CLASSPATH_CUSTOMER`), `webutil.cfg.overrides`, `cgicmd.dat.customer_keys` (without Oracle's sample keys), `uifont.ali.customer`, `custom_fonts_dir/`, `forms_java/` + `jars.txt`, `reports_servers.txt`, `environment.conf.proposal`, `web_tier.txt` (routing) + `web_tier_settings.txt` |
| `sources_inventory.csv`, `sources_files.txt`, `sources_dependencies.txt` | every configured Forms / Reports source directory (`FORMS_PATH`, `REPORTS_PATH`, `folderAccess`, `sourceDir`, WebUtil transfer dirs, icon path) with file counts per type; attached libraries / menus per `.fmx` (heuristic, `strings`), missing referenced files, TNS aliases vs. `tnsnames.ora` |
| `manifest.csv`, `secrets_locations.txt` | `category;source;stored;size;sha256`; where passwords are (file:line:keyword, never the value) |

**Never in the archive:** module files (`.fmb .fmx .pll .plx .mmb .mmx
.olb .rdf .rep`) – only their paths and counts; Oracle's own client jars
(`frmall.jar`, `frmsal.jar`, `frmwebutil.jar`, `frmmain.jar`, `frm*_laf.jar`,
`frmresources*.jar`, `frmwebsocketjsi.jar`) and `jacob.jar` (FSAL / JACOB
come from our 14- / 40- logic and are never overwritten; a renamed
`jacob_1.jar` is exported since 2026-11-26.1). A customer jar
named `frm….jar` is exported (until 2026-11-16.2 every `frm*.jar` was
skipped); `archive=` entries with subdirectories (`lib/x.jar`) are
resolved below `forms/java`, every other jar in `forms/java/lib/` too.
**Jar lists read** (2026-11-26.1): `archive*`, `WebUtilArchive`,
`cache_archive_ex` (`name;preload`), own keys containing `Archive`
(e.g. `FrmOptArchive`) and `fsal_archive` (resource file of the FSAL client,
e.g. `frmopt.properties`); relative names below the `codebase` of the
section. The same file name from two places is kept twice
(`forms_java/url_<path>/x.jar`);
free fonts (Liberation / DejaVu / Carlito / Caladea – OS packages, 14b-
deploys them).

**Fonts – three classes** (`ihw_import/fonts.txt` column `class`, grouped in
`00_report.txt`, since 2026-11-03.3):

| Class | Example | On 14c |
|---|---|---|
| `customer` | barcode (`IDAutomationC128L.ttf`), corporate fonts | must move – no replacement |
| `ms` | `arial*`, `times*`, `cour*`, `verdana*`, `calibri*`, Arial Unicode MS, Wingdings | licensed with Windows / Office **of the customer** – never into the library or git. 14c uses the free replacement: Arial / Times New Roman / Courier New / Arial Narrow / Calibri → Liberation / Carlito with **identical metrics** (same line breaks; Cambria → Caladea not set up yet); Verdana / Tahoma / Georgia … → DejaVu / Liberation only **similar** (line breaks and field widths can shift); symbol fonts (Wingdings, Symbol) have no replacement. The Windows licence does **not** allow copying these fonts to another server ("You may not copy them to other computers or servers", Microsoft font FAQ) – the original on the new server only with extended rights (Monotype / foundry). |
| `free` | Liberation, DejaVu | skipped – `14b-` deploys the OS packages |

All `customer` and `ms` files are copied into `ihw_import/custom_fonts_dir/`
(the export is the input for that decision). The import step must take only
`customer` plus the `ms` fonts the customer released. Mapping and PDF
background: [reports_fonts_architecture.md](../../80-FMW-Architecture/reports_fonts_architecture.md)
(licences, metric compatibility, migration path), [04-ReportsFonts/README.md](../../04-ReportsFonts/README.md)
(§7 "Windows-Specific Fonts on Linux": metric-compatible replacements, fonts requiring the original TTF, licence note).

**Customer data:** the export contains passwords, host names and paths – it
never goes into git (refused inside the repo; `.gitignore` has
`ihw_export_*` and `70-Customer-Projects/**/export/` for a copy placed there
for the import). Tested 2026-11-03 on 14.1.2 and on a simulated 12.2.1 tree
(`forms_12.2.1` / `reports_12.2.1`, standalone + in-process server).

## create_server_cert_from_pfx.sh

```bash
./create_server_cert_from_pfx.sh --in _.kunde.de.pfx --pwd pw.text                 # LIST only
./create_server_cert_from_pfx.sh --in _.kunde.de.pfx --pwd pw.text -o ./out --apply # write the 3 files
./create_server_cert_from_pfx.sh --in server.pfx                                   # password asked hidden
```

Splits a PFX / PKCS#12 container from the customer's PKI (often a wildcard
certificate) into the PEM files of a web server. The manual commands and the
background: [08-SSL/README.md – Manual: split a PFX](../../08-SSL/README.md#manual-split-a-pfx--pkcs12-also-wildcard-certificates).

| Option | Meaning |
|---|---|
| `--in FILE` | the PFX / P12 container |
| `--pwd FILE` | file with the container password in its first line (e.g. `pw.text` from the mail); without it the password is asked hidden – never on the command line |
| `-o DIR` | output directory for `--apply` (default: directory of the PFX); existing files are kept as `<file>.bak_<ts>` |
| `--apply` | write `server.key` (600, unencrypted), `server.cert` (leaf), `ca_chain.cert` (intermediates in order leaf issuer → root) |

**Without `--apply` (list):** OpenSSL version, password check ("WRONG
PASSWORD" = exit 2), container format / encryption, every certificate with
subject, issuer, names (SAN – the wildcard names), validity, CA yes / no,
key size, signature, SHA-256 fingerprint; expired / expiring within 30 days
/ SHA-1; which certificate matches the private key; chain order and
`openssl verify`. Nothing is written; the extracted key exists only in a
temporary 700 directory that is removed at the end.

OpenSSL 1.1.1 (OL 8) uses `-nodes`, OpenSSL 3 (OL 9) `-noenc`; an old RC2
container is read with `-legacy` on OpenSSL 3 automatically. Exit 0 = ok,
1 = findings (expired, no intermediate, key does not match …), 2 = error.
Tested 2026-11-16 with OpenSSL 3.5 and a test PKI (modern and RC2 PFX,
wrong password, PFX without and with reversed chain, `--apply` twice).

## ihw_tools_lib.sh

Shared helpers of the tools in `bash/` – **not** the IHateWeblogic library
(`00-Setup/IHateWeblogic_lib.sh`): no `environment.conf`, no
`ok`/`warn`/`fail`, functions only (prefix `ihwt_`), no output when sourced.
The tools source it from their own directory; the road map copies all
`tools/bash/*.sh`, so it always lies next to them.

| Function | Purpose |
|---|---|
| `ihwt_mask` | stdin → stdout, secrets masked (`<…password…>`, `<identifier>`, `{AES}`, `userid=` / `authid=` / `password=`, `-D…password=`, `user/pw@`) |
| `ihwt_sections FILE` / `ihwt_keys FILE` / `ihwt_cfgval FILE KEY` | ini / key=value parsing (formsweb.cfg, env files, webutil.cfg) |
| `ihwt_font_class NAME` | `class;replacement` of a font file (customer / ms / free) |
| `ihwt_git_guard DIR NAME` | refuse customer data inside a git work tree unless ignored |

Used by `export_forms_reports_conf.sh` (since 2026-11-04.1 – output checked
identical before / after), `collect_fmw_env.sh`, the operation tools and
`00-Setup/customer_conf_import.sh`.

## set_script_env.sh and the operation tools

Moved here on 2026-11-04 from `Reports14_linux_manual_install/tools/`; the
former `env.ini` (operation) and `install.ini` (installation) are now **one**
`patch_install.ini` per customer folder, the former `set_env.sh` (PATH,
`wlst`, `domain`) is replaced by `setdb`
([ihw_shell_env.sh](#ihw_shell_envsh), it puts `$ORACLE_BASE/tools` into the
PATH at login – variable `IHW_TOOLS_DIR`).

On the host everything lies in one directory:

```
$ORACLE_BASE/tools/
  status.sh  show_log.sh  show_errors.sh  show_all_logs.sh  set_script_env.sh  (755)
  patch_install.ini                                                            (600)
```

```bash
setdb 2t                                   # select the domain, cd to the tools
status.sh -q                               # uses the domain selected with setdb
status.sh --store-nm-key                   # once: Node Manager login for stage 3

. $ORACLE_BASE/tools/set_script_env.sh     # values for the cookbook commands
set_script_env_show                        # check: all values of the ini
IHW_INI=/path/other.ini status.sh          # another ini (test, second domain)
```

**Which values the four tools use** (`ihwt_ops_env` in `ihw_tools_lib.sh`, which
must lie next to them). The first match decides the domain; the ini is optional:

| # | Source | Rule |
|---|---|---|
| 1 | `IHW_INI=/path` set by hand | wins over everything |
| 2 | domain selected with `setdb` | wins over `patch_install.ini`; an ini with another domain gives a note on stderr and is ignored, except `EXTRA_PORTS` / `LOG_MINUTES` |
| 3 | `patch_install.ini` next to the tools | same domain as `setdb`, or no domain selected (also after a DB / "home only" entry) |
| 4 | `DOMAIN_HOME` of the login | no ini, `setdb` not used |
| – | nothing | `FEHLER: keine Domain bekannt`, rc 2 |

What the source does not give comes from the domain: `DOMAIN_NAME`,
`ADMIN_SERVER`, `WLS_ADMIN_PORT`, `MANAGED_SERVERS`, `REPORTS_SERVERS` from
`config.xml`; `NM_HOST`, `WLS_NODEMANAGER_PORT`, `NM_TYPE` from
`nodemanager.properties`. `status.sh` shows the source in its header.

**Node Manager keys of `status.sh`** (stage 3), first readable pair wins:
1. `WLST_CONFIG_FILE` / `WLST_KEY_FILE` of the ini;
2. `~/oracle-WebLogicConfig.properties` + `~/oracle-WebLogicKey.properties`;
3. `<base>/admin/<domain>/ctrl/keyfile/nm_config` + `nm_key` of the library
   autostart (`09-Install/30-configure_autostart.sh`).

Missing: the message lists the paths and names `status.sh --store-nm-key`. It
asks the Node Manager user and the password hidden, passes them to WLST through the
environment, runs `nmConnect` + `storeUserConfig` and sets mode 600. It needs a
terminal and a running Node Manager.

| Value in `patch_install.ini` | Used by |
|---|---|
| `DOMAIN_HOME`, `DOMAIN_NAME`, `ORACLE_HOME` | all four tools (`DOMAIN_NAME` etc. also from the domain, see above) |
| `ADMIN_SERVER`, `WLS_ADMIN_PORT`, `MANAGED_SERVERS` (`name:port …`) | `status.sh`, `show_log.sh` |
| `REPORTS_SERVERS` (default `$REPORTS_SERVER_NAME`) | `status.sh`, `show_log.sh` |
| `NM_HOST`, `WLS_NODEMANAGER_PORT`, `NM_TYPE`, `WLST_CONFIG_FILE`, `WLST_KEY_FILE` | `status.sh` stage 3 (Node Manager via WLST, stored login) |
| `EXTRA_PORTS` | `status.sh` stage 1 (e.g. Nginx `80 443`) |
| `LOG_MINUTES` | `show_all_logs.sh`, `show_errors.sh` |

No passwords in the ini. Cookbook:
[Tools_status_logs_kochbuch.txt](https://github.com/gpipperr/IHateWeblogic/blob/main/70-Customer-Projects/Reports14_linux_manual_install/Tools_status_logs_kochbuch.txt).
Tested 2026-11-06 on the test host from a scratch copy with an isolated `HOME`:
setdb domain without ini, ini with the same and another domain, `IHW_INI`, no
domain, a DB entry; `t`, `2t`, `9t`, `cdt`, `h`; stage 3 with the library keys, the
message without keys, `--store-nm-key` without terminal and without Node Manager.
A real `--store-nm-key` run needs the Node Manager password and is still open.

### make_patch_install_ini.sh

Creates `patch_install.ini` from the existing domain, for the cookbooks – the four
operation tools do not need it. `setdb` offers it once per session when `t` / `cdt`
finds no ini and a domain is selected; only on "y" it runs the tool.

```bash
make_patch_install_ini.sh            # shows every value with its source, writes nothing
make_patch_install_ini.sh --apply    # writes patch_install.ini next to the tool (600)
```

- **Domain:** the one selected with `setdb`, else `DOMAIN_HOME` of the login. Never
  an old ini; an existing file is not overwritten (rc 2). `IHW_INI=/path` sets
  another target.
- **Derived:** `setdb` (homes, JDK), `config.xml` + `nodemanager.properties`,
  `rwservlet.properties`, `rwserver.conf`, `rwnetwork.conf`, `reports.sh`
  (`TNS_ADMIN`), `opss-datasource-jdbc.xml` (RCU database, prefix).
- **To check, marked at the end:** `ORACLE_BASE` when it is not in the environment,
  `WLS_SERVER_FQDN` / `SSL_CN` (Nginx `server_name`, else the host name).
- **Commented out, "ANPASSEN":** `PATCH_STORAGE` / `MEDIA` when the directory does not
  exist, `RCU_DB_TYPE`, `SSL_*`. No sample values, no passwords.
- **`MANAGED_SERVERS` / `REPORTS_SERVERS` stay comments:** `status.sh` and `show_log.sh`
  read them live from the domain, so the ini is still right after
  `13- --remove-server`. A hand-written ini with these keys wins over the domain.

Tested 2026-11-06 on the test host from a scratch copy: all keys of the template
present (active or commented), `set_script_env.sh` and `status.sh` with the result,
no second write, the offer of `setdb` asks once.

### clean_domain_tmp.sh

Deletes what WebLogic rebuilds at the next start, for example after a patch or after
swapping the FMW home. Domain selection as for the operation tools (`setdb`, ini,
login). Call it as the owner of the domain.

```bash
clean_domain_tmp.sh            # shows the directories and sizes, deletes nothing
clean_domain_tmp.sh --apply    # deletes, only when nothing runs any more
```

- **Deleted:** the contents of `servers/<server>/tmp` and `servers/<server>/cache`
  (`_WL_user`, `_WL_internal`, `.lok` files). The directories stay. Links are not followed.
- **Kept:** `servers/*/data` (embedded LDAP, stores), `security`, `logs`, `adr`, `stage`
  (may hold deployments, a note is shown), `reports/cache` (job results), `config/`.
- **Refuses (rc 1)** while a `java`, `frmweb`, `rwserver` … process runs that belongs to
  this domain (command line or working directory) or to this home (`frmweb` names no
  domain). This also stops the tool when another domain of the same home is still
  running. A shell inside the domain or a `tail -f` on a log does not count. Servers on
  other hosts are not seen; the tool only deletes on its own host.
- **Afterwards:** the first start takes longer, the applications are unpacked again.
- **Background:** what a patch changes in the home and in the domain, and what a swapped
  home needs:
  [weblogic_middleware_architecture.md §7a](../../80-FMW-Architecture/weblogic_middleware_architecture.md#7a-what-a-patch-changes--oracle-home-domain-home-swapped-home).

Tested 2026-11-06: dry run on the running test host (all processes listed, rc 1, nothing
changed); `--apply` only on an isolated copy (protected directories and link targets
kept, refusal with a running process). The first real start after a real `--apply` is
still open.

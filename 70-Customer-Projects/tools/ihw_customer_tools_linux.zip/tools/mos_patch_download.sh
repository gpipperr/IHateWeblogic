#!/bin/bash
# =============================================================================
# Script   : mos_patch_download.sh
# Purpose  : Download a list of My Oracle Support patches (CSV) in one run with
#            getMOSPatch.jar - the right platform and file per patch, a check
#            of every ZIP (unzip -t, SHA-256) and a summary.
#            Standalone - no IHateWeblogic library, plain bash + coreutils +
#            Java (for getMOSPatch) + python (pseudo terminal for the password).
# Call     : ./mos_patch_download.sh -c <patches.csv> -d <patch dir> [--apply]
#              -c FILE      patch list (format: see the header of the CSV files
#                           in 70-Customer-Projects/*/patches_*.csv and
#                           09-Install/download/patches_*.csv)
#              -d DIR       target directory, one sub-directory per patch
#                           (column "dir" relative to DIR, default <patch>)
#              -j JAR       getMOSPatch.jar (default: ./getMOSPatch.jar, then
#                           <DIR>/getMOSPatch.jar, then the script directory)
#              -u USER      MOS user (default: $MOS_USER, else asked)
#              --all        also the rows with required=optional
#              --only N,N   only these patch numbers
#              --steps S,S  only rows with these values in column "step"
#                           (library roles: spb,wls,jdk,...) - optional rows
#                           included
#              --java JAVA  Java binary (default: $JAVA_HOME/bin/java, java in PATH)
#              --proxy H:P  HTTPS proxy for getMOSPatch (-Dhttps.proxyHost/Port);
#                           default: $https_proxy / $HTTPS_PROXY
#              --password-stdin  read the MOS password from stdin (first line)
#                           instead of asking - for callers like
#                           09-Install/04-oracle_pre_download.sh
#              --apply      download (default: show the plan only)
#            The MOS password is asked once (hidden) and typed into
#            getMOSPatch through a pseudo terminal - never on a command line,
#            never stored, masked in the output.
# CSV      : patch;platform;file_regexp;required;step;description[;dir[;sha256[;aru]]]
#            dir / sha256 / aru optional (6- and 8-column lists keep working).
#            sha256 and aru are SOFT checks: a different value only WARNs -
#            Oracle re-releases patches under the same number (unzip -t stays
#            the hard check). aru = Unique Patch ID of the build, read from
#            <patch>/etc/config/inventory.xml in the ZIP (= "Unique Patch ID"
#            of opatch lsinventory); empty for ZIPs without an OPatch inventory
#            (Stack Patch Bundle, OPatch, JDK, CVU).
# Output   : <DIR>/<dir>/p<patch>_*.zip, <DIR>/patches_sha256.txt,
#            <DIR>/patches_sha256.csv (patch;step;file;sha256;aru - to fill the
#            sha256 / aru columns), <DIR>/mos_patch_download_<ts>.log
# Exit     : 0 = all required patches present, 1 = optional missing or SHA-256 /
#            ARU differs from the list, 2 = required missing / error
# Doc      : 70-Customer-Projects/tools/README.md
# Author   : Gunther Pipperr | https://pipperr.de
# License  : Apache 2.0
# =============================================================================
set -u
umask 022
VERSION="2026-11-17.1"   # bump on every change

CSV=""; DIR=""; JAR=""; MOS_USER="${MOS_USER:-}"; ALL=false; ONLY=""; APPLY=false
JAVA_BIN=""; PROXY=""; LANG_CODE="4L"; RETRIES=3; STEPS=""; PWD_STDIN=false
while [ $# -gt 0 ]; do
    case "$1" in
        -c) CSV="${2:-}"; shift ;;
        -d) DIR="${2:-}"; shift ;;
        -j) JAR="${2:-}"; shift ;;
        -u) MOS_USER="${2:-}"; shift ;;
        --all) ALL=true ;;
        --only) ONLY=",${2:-},"; shift ;;
        --steps) STEPS=",${2:-},"; shift ;;
        --password-stdin) PWD_STDIN=true ;;
        --java) JAVA_BIN="${2:-}"; shift ;;
        --proxy) PROXY="${2:-}"; shift ;;
        --apply) APPLY=true ;;
        -h|--help) sed -n '2,49p' "$0"; printf 'Version: %s\n' "$VERSION"; exit 0 ;;
        -V|--version) printf '%s\n' "$VERSION"; exit 0 ;;
        *) printf 'Unknown option: %s\n' "$1" >&2; exit 2 ;;
    esac
    shift
done
[ -n "$CSV" ] && [ -n "$DIR" ] || { sed -n '9,29p' "$0"; exit 2; }
[ -f "$CSV" ] || { printf 'CSV not found: %s\n' "$CSV" >&2; exit 2; }

mkdir -p "$DIR" || { printf 'Cannot create %s\n' "$DIR" >&2; exit 2; }
DIR="$(cd "$DIR" && pwd)"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG="$DIR/mos_patch_download_$(date +%Y%m%d_%H%M%S).log"
N_OK=0; N_WARN=0; N_FAIL=0

# --- output helpers (stdout + log) ----------------------------------------------
_p()   { printf '%s\n' "$*" | tee -a "$LOG"; }
ok()   { N_OK=$((N_OK + 1));     printf '\033[32m  OK  \033[0m %s\n' "$*"; printf '  OK   %s\n' "$*" >> "$LOG"; }
warn() { N_WARN=$((N_WARN + 1)); printf '\033[33m WARN \033[0m %s\n' "$*"; printf ' WARN  %s\n' "$*" >> "$LOG"; }
fail() { N_FAIL=$((N_FAIL + 1)); printf '\033[31m FAIL \033[0m %s\n' "$*"; printf ' FAIL  %s\n' "$*" >> "$LOG"; }
info() { printf '       %s\n' "$*" | tee -a "$LOG"; }
section() { _p ""; _p "=== $* ==="; }

_p "mos_patch_download.sh $VERSION – $(date '+%Y-%m-%d %H:%M:%S') – $(hostname -s 2>/dev/null)"
_p "CSV : $CSV"
_p "Dir : $DIR"
_p "Mode: $($APPLY && printf 'APPLY (download)' || printf 'plan only (use --apply to download)')"

# =============================================================================
# 1. Prerequisites
# =============================================================================
section "1. Prerequisites"
if [ -z "$JAVA_BIN" ]; then
    if [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/java" ]; then JAVA_BIN="$JAVA_HOME/bin/java"
    else JAVA_BIN="$(command -v java 2>/dev/null)"; fi
fi
if [ -n "$JAVA_BIN" ] && [ -x "$JAVA_BIN" ]; then
    ok "Java: $JAVA_BIN ($("$JAVA_BIN" -version 2>&1 | head -1))"
else
    fail "No Java found – set JAVA_HOME or use --java"
fi
if [ -z "$JAR" ]; then
    for _j in ./getMOSPatch.jar "$DIR/getMOSPatch.jar" "$SCRIPT_DIR/getMOSPatch.jar"; do
        [ -f "$_j" ] && { JAR="$(cd "$(dirname "$_j")" && pwd)/$(basename "$_j")"; break; }
    done
fi
[ -n "$JAR" ] && [ -f "$JAR" ] && ok "getMOSPatch: $JAR" \
    || fail "getMOSPatch.jar not found (-j, ./, $DIR, $SCRIPT_DIR) – see tools/README.md"
for _t in unzip sha256sum; do
    command -v "$_t" > /dev/null 2>&1 && ok "$_t found" || fail "$_t not installed"
done
PY=""
for _p in python3 /usr/libexec/platform-python python; do
    command -v "$_p" > /dev/null 2>&1 && { PY="$(command -v "$_p")"; break; }
done
[ -n "$PY" ] && ok "python for the password terminal: $PY" \
    || warn "no python – getMOSPatch asks for user / password itself for every patch"
_free="$(df -Pk "$DIR" | awk 'NR==2 { printf "%d", $4 / 1048576 }')"
if [ "${_free:-0}" -lt 15 ]; then warn "Free space in $DIR: ${_free} GB (recommended >= 15 GB for a CPU set)"
else ok "Free space in $DIR: ${_free} GB"; fi
JAVA_OPTS=()
# proxy: --proxy, else the shell variable (curl/wget use it, java ignores it)
if [ -z "$PROXY" ]; then
    PROXY="${https_proxy:-${HTTPS_PROXY:-}}"
    PROXY="${PROXY#*://}"; PROXY="${PROXY#*@}"; PROXY="${PROXY%%/*}"
fi
if [ -n "$PROXY" ]; then
    _ph="${PROXY%%:*}"; _pp=80; [ "$_ph" != "$PROXY" ] && _pp="${PROXY##*:}"
    JAVA_OPTS=(-Dhttps.proxyHost="$_ph" -Dhttps.proxyPort="$_pp" -Dhttp.proxyHost="$_ph" -Dhttp.proxyPort="$_pp")
    info "HTTPS proxy: $_ph:$_pp"
fi
[ "$N_FAIL" -gt 0 ] && { _p ""; _p "Prerequisites missing – nothing downloaded"; exit 2; }

# =============================================================================
# 2. Read the CSV
# =============================================================================
section "2. Patch list"
ROWS=()
while IFS= read -r _line || [ -n "$_line" ]; do
    _line="${_line%$'\r'}"
    case "$_line" in ''|'#'*|patch\;*) continue ;; esac
    # more than 9 columns = a ";" inside a field (description) - the columns
    # shift and the ZIP lands in a wrong directory (patches_db.csv, 2026-11-02)
    _semi="${_line//[^;]/}"
    [ "${#_semi}" -le 8 ] || { fail "skipped line (more than 9 columns – ';' in a field?): $_line"; continue; }
    IFS=';' read -r _nr _plat _re _req _step _desc _dir _sha _aru <<< "$_line"
    [[ "$_nr" =~ ^[0-9]+$ ]] || { warn "skipped line (no patch number): $_line"; continue; }
    if [ -n "$ONLY" ] && [[ "$ONLY" != *",$_nr,"* ]]; then continue; fi
    if [ -n "$STEPS" ] && [[ "$STEPS" != *",$_step,"* ]]; then continue; fi
    if [ "${_req:-yes}" != "yes" ] && ! $ALL && [ -z "$ONLY" ] && [ -z "$STEPS" ]; then
        info "$(printf '%-10s optional – skipped (use --all)  %s' "$_nr" "$_desc")"; continue
    fi
    ROWS+=("$_nr;$_plat;$_re;${_req:-yes};$_step;$_desc;${_dir:-$_nr};$_sha;$_aru")
    info "$(printf '%-10s %-11s step %-10s %-9s %s' "$_nr" "$_plat" "${_step:--}" "${_req:-yes}" "$_desc")"
done < "$CSV"
[ "${#ROWS[@]}" -gt 0 ] || { fail "no patch selected"; exit 2; }
info "${#ROWS[@]} patch(es) selected"

# _zip_upi ZIP NR - Unique Patch ID (ARU) of the build from the OPatch inventory
# in the ZIP: <NR>/etc/config/inventory.xml, else the only inventory.xml of the
# ZIP; nothing for ZIPs with none or several (Stack Patch Bundle, JDK, OPatch)
_zip_upi() {
    local lst inv
    lst="$(unzip -Z1 "$1" 2>/dev/null)" || return 0
    inv="$(printf '%s\n' "$lst" | grep -xE "$2/etc/config/inventory\.xml" | head -1)"
    if [ -z "$inv" ] && [ "$(printf '%s\n' "$lst" | grep -cE '(^|/)etc/config/inventory\.xml$')" = 1 ]; then
        inv="$(printf '%s\n' "$lst" | grep -E '(^|/)etc/config/inventory\.xml$')"
    fi
    [ -n "$inv" ] || return 0
    unzip -p "$1" "$inv" 2>/dev/null | grep -oE '<unique_patch_id>[0-9]+' | grep -oE '[0-9]+$' | head -1
}

# _have NR REGEX SUBDIR - is a matching ZIP already in <DIR>/<SUBDIR>/ ?
_have() {
    local f b
    for f in "$DIR/${3:-$1}"/*.zip; do
        [ -f "$f" ] || continue; b="$(basename "$f")"
        if [ -n "$2" ]; then [[ "$b" =~ ^$2$ ]] && return 0
        else [[ "$b" == p"$1"_* ]] && return 0; fi
    done
    return 1
}

if ! $APPLY; then
    section "Plan"
    for _r in "${ROWS[@]}"; do
        IFS=';' read -r _nr _plat _re _req _step _desc _dir _sha _aru <<< "$_r"
        if _have "$_nr" "$_re" "$_dir"; then info "$(printf '%-10s present – will be skipped  %s' "$_nr" "$_dir")"
        else info "$(printf '%-10s download  platform %-11s file %s -> %s' "$_nr" "$_plat" "${_re:-<all>}" "$_dir")"; fi
    done
    _p ""; _p "Plan only – start with --apply (MOS user + password are asked once)"
    exit 0
fi

# =============================================================================
# 3. Download
# =============================================================================
section "3. Download"
if $PWD_STDIN; then
    [ -n "$MOS_USER" ] || { fail "--password-stdin needs -u USER or \$MOS_USER"; exit 2; }
    IFS= read -r MOS_PWD
else
    if [ -z "$MOS_USER" ]; then printf '  MOS user (e-mail): '; read -r MOS_USER; fi
    printf '  MOS password for %s: ' "$MOS_USER"; read -rs MOS_PWD; printf '\n'
fi
[ -n "$MOS_PWD" ] || { fail "empty password"; exit 2; }

# _gmp ARGS... - getMOSPatch in a pseudo terminal; user / password typed when
# asked (same mechanism as 09-Install/04-oracle_pre_download.sh, 2026-10-20)
_gmp() {
    if [ -z "$PY" ]; then
        "$JAVA_BIN" "${JAVA_OPTS[@]}" -jar "$JAR" "$@"; return $?
    fi
    printf '%s\n%s\n' "$MOS_USER" "$MOS_PWD" | "$PY" -I -c '
import os, pty, select, sys
user = sys.stdin.readline().rstrip("\n"); pwd = sys.stdin.readline().rstrip("\n")
pid, fd = pty.fork()
if pid == 0:
    os.execvp(sys.argv[1], sys.argv[1:])
tail, sent_u, sent_p = b"", False, False
while True:
    r, _, _ = select.select([fd], [], [], 1800)
    if not r:
        break
    try:
        d = os.read(fd, 4096)
    except OSError:
        break
    if not d:
        break
    tail = (tail + d)[-300:].lower()
    if not sent_u and b"username" in tail:
        os.write(fd, (user + "\n").encode()); sent_u, tail = True, b""
    elif sent_u and not sent_p and b"password" in tail:
        os.write(fd, (pwd + "\n").encode()); sent_p, tail = True, b""
    if pwd:
        d = d.replace(pwd.encode(), b"****")
    sys.stdout.buffer.write(d); sys.stdout.flush()
_, st = os.waitpid(pid, 0)
sys.exit(os.WEXITSTATUS(st) if os.WIFEXITED(st) else 1)
' "$JAVA_BIN" "${JAVA_OPTS[@]}" -jar "$JAR" "$@"
}

for _r in "${ROWS[@]}"; do
    IFS=';' read -r _nr _plat _re _req _step _desc _dir _sha _aru <<< "$_r"
    _d="$DIR/$_dir"
    if _have "$_nr" "$_re" "$_dir"; then ok "$(printf '%-10s already present – skipped (%s)' "$_nr" "$_dir")"; continue; fi
    mkdir -p "$_d"
    _got=false
    IFS='|' read -r -a _plats <<< "$_plat"
    for _pl in "${_plats[@]}"; do
        printf '%s;%s\n' "$_pl" "$LANG_CODE" > "$_d/.getMOSPatch.cfg"   # read from the working dir
        for _try in $(seq 1 "$RETRIES"); do
            info "$(printf '%-10s platform %s, attempt %s – %s' "$_nr" "$_pl" "$_try" "$_desc")"
            # getMOSPatch matches the regexp (String.matches) against the file
            # name WITHOUT ".zip" – strip a trailing \.zip / .zip of the CSV value
            _gre="${_re%\\.zip}"; _gre="${_gre%.zip}"
            _args=("patch=$_nr" "download=all"); [ -n "$_gre" ] && _args+=("regexp=$_gre")
            _out="$(cd "$_d" && _gmp "${_args[@]}" 2>&1)"
            printf '%s\n' "$_out" >> "$LOG"
            if _have "$_nr" "$_re" "$_dir"; then _got=true; break; fi
            printf '%s\n' "$_out" | grep -qi 'no files available\|not available for' && break
            sleep 10
        done
        $_got && break
    done
    if $_got; then
        ok "$(printf '%-10s downloaded (platform %s)' "$_nr" "$_pl")"
    elif [ "$_req" = "yes" ]; then
        fail "$(printf '%-10s not downloaded – %s' "$_nr" "$(printf '%s\n' "$_out" | grep -iE 'error|not|denied|invalid' | tail -1)")"
    else
        warn "$(printf '%-10s (optional) not downloaded' "$_nr")"
    fi
done
MOS_PWD="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"; unset MOS_PWD

# =============================================================================
# 4. Check
# =============================================================================
section "4. Check (unzip -t, SHA-256)"
SUMFILE="$DIR/patches_sha256.txt"
SUMCSV="$DIR/patches_sha256.csv"
: > "$SUMFILE"; printf 'patch;step;file;sha256;aru\n' > "$SUMCSV"
_missing_req=0; _missing_opt=0; _sha_diff=0; _aru_diff=0
for _r in "${ROWS[@]}"; do
    IFS=';' read -r _nr _plat _re _req _step _desc _dir _sha _aru <<< "$_r"
    _f=""
    for _z in "$DIR/$_dir"/*.zip; do
        [ -f "$_z" ] || continue; _b="$(basename "$_z")"
        if [ -z "$_re" ] || [[ "$_b" =~ ^$_re$ ]]; then _f="$_z"; break; fi
    done
    if [ -z "$_f" ]; then
        [ "$_req" = "yes" ] && _missing_req=$((_missing_req + 1)) || _missing_opt=$((_missing_opt + 1))
        continue
    fi
    if unzip -tq "$_f" > /dev/null 2>&1; then
        _is="$(sha256sum "$_f" | awk '{print tolower($1)}')"
        printf '%s  %s\n' "$_is" "${_f#$DIR/}" >> "$SUMFILE"
        _upi="$(_zip_upi "$_f" "$_nr")"
        printf '%s;%s;%s;%s;%s\n' "$_nr" "$_step" "$(basename "$_f")" "$_is" "$_upi" >> "$SUMCSV"
        ok "$(printf '%-10s %-42s %6s  %s…  ARU %s' "$_nr" "$(basename "$_f")" "$(du -h "$_f" | cut -f1)" "${_is:0:16}" "${_upi:--}")"
        # soft check: same patch number, other build (= new ARU / Unique Patch ID)
        if [ -n "$_aru" ] && [ -n "$_upi" ] && [ "$_upi" != "$_aru" ]; then
            warn "$(printf '%-10s ARU %s differs from the list (%s) – Oracle re-released the patch as a new build; read the README, then update the CSV' "$_nr" "$_upi" "$_aru")"
            _aru_diff=$((_aru_diff + 1))
        fi
        # soft check: Oracle re-releases patches under the same number
        if [ -n "$_sha" ] && [ "$_is" != "$(printf '%s' "$_sha" | tr 'A-F' 'a-f')" ]; then
            warn "$(printf '%-10s SHA-256 differs from the list (%s…) – re-released by Oracle? compare the digest on MOS, then update the CSV' "$_nr" "${_sha:0:16}")"
            _sha_diff=$((_sha_diff + 1))
        fi
    else
        fail "$(printf '%-10s %s is damaged (unzip -t) – delete it and run again' "$_nr" "$(basename "$_f")")"
        [ "$_req" = "yes" ] && _missing_req=$((_missing_req + 1)) || _missing_opt=$((_missing_opt + 1))
    fi
done
info "SHA-256 list: $SUMFILE  (compare with the values on MOS); sha256 + aru per file: $SUMCSV"

_p ""
_p "=== Summary: OK $N_OK  WARN $N_WARN  FAIL $N_FAIL – log $LOG"
[ "$_missing_req" -gt 0 ] && { _p "$_missing_req required patch(es) missing"; exit 2; }
[ "$N_FAIL" -gt 0 ] && exit 2
[ "$_missing_opt" -gt 0 ] && { _p "$_missing_opt optional patch(es) missing"; exit 1; }
[ "$_sha_diff" -gt 0 ] && { _p "$_sha_diff file(s) with a SHA-256 other than in the list (WARN)"; exit 1; }
[ "$_aru_diff" -gt 0 ] && { _p "$_aru_diff file(s) with an ARU other than in the list (WARN)"; exit 1; }
exit 0
